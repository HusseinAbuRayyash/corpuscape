# TransCorpus AI – ATISA 2026 Pre-Workshop

Full web tool for AI-assisted corpus work in Translation Studies.
Run locally or deploy to Streamlit Cloud.

**Run:** `streamlit run app.py`

**Author:** Hussein Abu-Rayyash
