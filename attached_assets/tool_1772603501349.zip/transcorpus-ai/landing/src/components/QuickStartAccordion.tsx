import { ChevronDown } from "lucide-react";
import { useState } from "react";

const CONTENT = `Add your **Gemini API key** in the sidebar (Settings). Then choose a track above.
Monolingual: stats, keywords, collocations, concordance. Bilingual: alignment, strategies, TMX. AI Insights: domain classification, term clusters. Export: CSV, Excel, TMX, Research Report.`;

export function QuickStartAccordion() {
  const [open, setOpen] = useState(false);

  return (
    <div className="mx-auto mt-16 max-w-[600px] px-4">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between rounded-xl border border-[#E6E8EC] bg-white py-4 px-5 text-left transition-all duration-200 ease-in-out hover:border-[#E6E8EC] hover:bg-[#F7F8FA]/50"
      >
        <span className="text-sm font-medium text-[#111418]">
          Quick start & tips
        </span>
        <ChevronDown
          className={`h-4 w-4 text-[#5C6670] transition-transform duration-200 ease-in-out ${
            open ? "rotate-180" : ""
          }`}
          strokeWidth={2}
        />
      </button>
      <div
        className="grid transition-[grid-template-rows] duration-200 ease-in-out"
        style={{
          gridTemplateRows: open ? "1fr" : "0fr",
        }}
      >
        <div className="overflow-hidden">
          <div className="rounded-b-xl border border-t-0 border-[#E6E8EC] bg-white px-5 py-4">
          <p className="whitespace-pre-line text-sm leading-relaxed text-[#5C6670]">
            {CONTENT.replace(/\*\*(.*?)\*\*/g, "$1")}
          </p>
          </div>
        </div>
      </div>
    </div>
  );
}
