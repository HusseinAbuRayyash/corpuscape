import { BookOpen, Globe, Sparkles } from "lucide-react";
import { TRACK_ROUTES } from "../config";
import { TrackCard } from "./TrackCard";

const TRACKS = [
  {
    title: "Monolingual",
    description:
      "Explore reception, register, and discourse patterns in a single corpus.",
    example: "Example: Keyword dispersion across 12 film subtitle corpora.",
    icon: BookOpen,
    accentClass: "mono" as const,
    buttonLabel: "Start analysis →",
    href: TRACK_ROUTES.monolingual,
  },
  {
    title: "Bilingual",
    description: "Align EN→AR corpora, trace shifts, export TMX.",
    example: "Example: Domestication strategies in literary translations.",
    icon: Globe,
    accentClass: "bi" as const,
    buttonLabel: "Start alignment →",
    href: TRACK_ROUTES.bilingual,
  },
  {
    title: "AI Insights",
    description: "Cluster domains, probe semantics, detect hidden patterns.",
    example: "Example: 31 specialized analysis types, term clusters.",
    icon: Sparkles,
    accentClass: "ai" as const,
    buttonLabel: "Run probes →",
    href: TRACK_ROUTES.aiInsights,
  },
];

export function TrackGrid() {
  return (
    <div className="grid grid-cols-1 gap-8 px-4 md:grid-cols-2 lg:grid-cols-3 lg:gap-8">
      {TRACKS.map((track, i) => (
        <TrackCard
          key={track.title}
          {...track}
          animationDelay={60 * (i + 1)}
        />
      ))}
    </div>
  );
}
