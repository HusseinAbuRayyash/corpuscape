import type { LucideIcon } from "lucide-react";

export interface TrackCardProps {
  title: string;
  description: string;
  example: string;
  icon: LucideIcon;
  accentClass: "mono" | "bi" | "ai";
  buttonLabel: string;
  href: string;
  animationDelay?: number;
}

export function TrackCard({
  title,
  description,
  example,
  icon: Icon,
  accentClass,
  buttonLabel,
  href,
  animationDelay = 0,
}: TrackCardProps) {
  return (
    <a
      href={href}
      data-accent={accentClass}
      className="track-card group block animate-card-stagger rounded-2xl bg-white p-8 shadow-sm transition-all duration-200 ease-in-out hover:-translate-y-1.5"
      style={{ animationDelay: `${animationDelay}ms` }}
    >
      <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl text-[#5C6670] transition-colors duration-200 group-hover:bg-[var(--accent-bg)] group-hover:text-[var(--accent)]">
        <Icon className="h-5 w-5" strokeWidth={1.5} />
      </div>
      <h3 className="text-xl font-medium text-[#111418]">{title}</h3>
      <p className="mt-2 text-base leading-relaxed text-[#5C6670]">
        {description}
      </p>
      <p className="mt-3 text-sm italic text-[#5C6670]/80">{example}</p>
      <span className="card-btn mt-6 inline-flex items-center rounded-xl bg-[var(--accent-bg)] px-4 py-2 text-sm font-medium text-[var(--accent)] transition-all duration-200 ease-in-out group-hover:scale-[1.02] active:scale-[0.98]">
        {buttonLabel}
      </span>
    </a>
  );
}
