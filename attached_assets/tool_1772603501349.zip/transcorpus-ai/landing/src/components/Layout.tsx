import type { ReactNode } from "react";
import { TopBar } from "./TopBar";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-[#F7F8FA]">
      <TopBar />
      <main className="relative">
        <div className="hero-bg-gradient absolute inset-0 -z-10" />
        <div className="hero-bg-grid absolute inset-0 -z-10" />
        {children}
      </main>
    </div>
  );
}
