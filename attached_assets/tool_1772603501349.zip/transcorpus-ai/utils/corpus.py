import re
import math
from docx import Document
import PyPDF2
from collections import Counter
import pandas as pd

def load_files(uploaded_files):
    text = ""
    for file in uploaded_files:
        if file.name.endswith(".txt"):
            text += file.getvalue().decode("utf-8") + "\n\n"
        elif file.name.endswith(".docx"):
            doc = Document(file)
            text += "\n".join([p.text for p in doc.paragraphs]) + "\n\n"
        elif file.name.endswith(".pdf"):
            pdf = PyPDF2.PdfReader(file)
            text += "\n".join([page.extract_text() for page in pdf.pages]) + "\n\n"
        elif file.name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(file, header=None)
            cells = df.fillna("").astype(str).values.flatten()
            text += " ".join(c for c in cells if c.strip()) + "\n\n"
    return text

def clean_text(text):
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def get_stats(text):
    words = text.split()
    unique = len(set(w.lower() for w in words))
    sentences = max(1, len(re.findall(r'[.!?]+', text)))
    return {
        "Characters": len(text),
        "Words": len(words),
        "Unique words": unique,
        "Sentences": sentences,
        "Type-Token Ratio": round(unique / len(words), 4) if words else 0,
        "Avg words/sentence": round(len(words) / sentences, 1) if words else 0,
    }

def extract_keywords(text, top_n=30):
    words = [w.lower() for w in text.split() if len(w) > 3]
    cnt = Counter(words)
    df = pd.DataFrame(cnt.most_common(top_n), columns=["Term", "Frequency"])
    return df

def extract_ngrams(text, n=2, top_n=25):
    """Extract n-grams (bigrams, trigrams, etc.) with frequency."""
    words = [w.lower() for w in text.split() if len(w) > 2]
    ngrams = [" ".join(words[i:i+n]) for i in range(len(words)-n+1)]
    cnt = Counter(ngrams)
    return pd.DataFrame(cnt.most_common(top_n), columns=["N-gram", "Frequency"])

def extract_collocations(text, node_word=None, top_n=20, min_freq=2):
    """Extract collocations with MI (Mutual Information) and Dice. If node_word given, show collocates of that word."""
    words = [w.lower() for w in text.split() if len(w) > 2]
    n_total = len(words)
    if n_total < 10:
        return pd.DataFrame(columns=["Collocate", "Frequency", "MI", "Dice"])
    bigrams = [tuple(words[i:i+2]) for i in range(len(words)-1)]
    cnt_bigrams = Counter(bigrams)
    cnt_words = Counter(words)
    rows = []
    for (a, b), f in cnt_bigrams.items():
        if f < min_freq:
            continue
        if node_word:
            node = node_word.lower()
            if a != node and b != node:
                continue
        c_a, c_b = cnt_words[a], cnt_words[b]
        p_a, p_b = c_a / n_total, c_b / n_total
        p_ab = f / n_total
        mi = math.log2(p_ab / (p_a * p_b)) if (p_a * p_b) > 0 else 0
        dice = 2 * f / (c_a + c_b) if (c_a + c_b) > 0 else 0
        rows.append({"Collocate": f"{a} ... {b}", "Frequency": f, "MI": round(mi, 2), "Dice": round(dice, 3)})
    df = pd.DataFrame(rows)
    if len(df) > 0:
        df = df.sort_values("MI", ascending=False).head(top_n)
    return df if len(df) > 0 else pd.DataFrame(columns=["Collocate", "Frequency", "MI", "Dice"])

def concordance(text, query, context_words=5, max_hits=50):
    """Key Word In Context: find query and return surrounding context."""
    words = text.split()
    query_lower = query.lower().strip()
    qwords = query_lower.split()
    hits = []
    i = 0
    while i < len(words) and len(hits) < max_hits:
        matched = False
        match_text = ""
        if len(qwords) == 1:
            if words[i].lower() == query_lower or query_lower in words[i].lower():
                matched = True
                match_text = words[i]
        else:
            window = " ".join(w.lower() for w in words[i:i+len(qwords)])
            if query_lower in window or window.startswith(query_lower):
                matched = True
                match_text = " ".join(words[i:i+len(qwords)])
        if matched:
            left = " ".join(words[max(0, i-context_words):i])
            right_start = i + (len(qwords) if len(qwords) > 1 else 1)
            right = " ".join(words[right_start:right_start+context_words])
            hits.append({"Left": left, "Match": match_text, "Right": right})
            i = right_start
        else:
            i += 1
    return pd.DataFrame(hits) if hits else pd.DataFrame(columns=["Left", "Match", "Right"])
