import { HeroSection } from "./components/HeroSection";
import { Layout } from "./components/Layout";
import { QuickStartAccordion } from "./components/QuickStartAccordion";
import { TrackGrid } from "./components/TrackGrid";

function App() {
  return (
    <Layout>
      <div className="mx-auto max-w-[1100px] px-6 pb-24 pt-6">
        <HeroSection />
        <TrackGrid />
        <QuickStartAccordion />
      </div>
    </Layout>
  );
}

export default App;
