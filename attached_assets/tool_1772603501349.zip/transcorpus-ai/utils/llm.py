import google.generativeai as genai
from openai import OpenAI
import numpy as np
from sentence_transformers import SentenceTransformer
import pandas as pd

embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

GEMINI_MODELS = ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro", "gemini-pro"]

def get_llm_response(system_prompt, user_text, gemini_key=None, openai_key=None, model_choice="gemini"):
    if model_choice == "gemini" and gemini_key:
        try:
            genai.configure(api_key=gemini_key.strip())
            last_err = None
            for model_name in GEMINI_MODELS:
                try:
                    llm = genai.GenerativeModel(model_name)
                    response = llm.generate_content(f"{system_prompt}\n\nText:\n{user_text[:12000]}")
                    return response.text
                except Exception as e:
                    last_err = e
                    if "404" in str(e) or "not found" in str(e).lower():
                        continue
                    raise
            return f"**Model error:** No Gemini model available. Try again later. ({last_err})"
        except Exception as e:
            err = str(e).lower()
            if "api key" in err or "invalid" in err or "api_key" in err:
                return "**API key invalid.** Get a free key at https://aistudio.google.com/app/apikey — then paste it in the sidebar (remove spaces)."
            return f"**Error:** {str(e)}"
    elif model_choice == "gpt" and openai_key:
        client = OpenAI(api_key=openai_key)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": user_text[:12000]}]
        )
        return response.choices[0].message.content
    return "No API key provided"

def get_embeddings(texts):
    return embedding_model.encode(texts, convert_to_numpy=True)

def semantic_search(text, query, gemini_key):
    sentences = [s.strip() for s in text.split('.') if len(s.strip()) > 10]
    if not sentences:
        return "No sentences found to search."
    emb = get_embeddings(sentences)
    q_emb = get_embeddings([query])[0]
    scores = np.dot(emb, q_emb)
    top_idx = scores.argsort()[-8:][::-1]
    results = "\n\n".join([f"**{i+1}.** {sentences[i]}" for i in top_idx])
    return get_llm_response("Summarize the most relevant contexts for this query in Translation Studies", results, gemini_key)

def ai_summarize(text, gemini_key, max_chars=15000):
    """AI-powered corpus summarization."""
    prompt = """Summarize this corpus in 3-5 concise paragraphs for a translation studies researcher. Cover: main themes, register/style, key terminology domains, and any notable patterns. Be specific."""
    return get_llm_response(prompt, text[:max_chars], gemini_key)

def ai_extract_topics(text, gemini_key, n_topics=8, max_chars=12000):
    """AI extract themes/topics. Returns structured text for table parsing."""
    prompt = f"""Extract exactly {n_topics} main topics/themes from this corpus. For each topic provide:
1. Topic name (2-4 words)
2. Brief description
3. Example keywords from the text

Format as a numbered list. Each item: "TopicName | Description | keyword1, keyword2, keyword3" """
    return get_llm_response(prompt, text[:max_chars], gemini_key)

def ai_extract_topics_table(text, gemini_key, n_topics=8, max_chars=10000):
    """AI extract topics and return as list of dicts for DataFrame."""
    raw = ai_extract_topics(text, gemini_key, n_topics, max_chars)
    rows = []
    for line in raw.strip().split("\n"):
        line = line.strip()
        if not line or len(line) < 5:
            continue
        if "|" in line:
            parts = [p.strip() for p in line.split("|", 2)]
            topic = parts[0].lstrip("0123456789.-) ")
            if len(parts) >= 3:
                rows.append({"Topic": topic, "Description": parts[1], "Keywords": parts[2]})
            elif len(parts) == 2:
                rows.append({"Topic": topic, "Description": parts[1], "Keywords": ""})
        elif ". " in line or ") " in line:
            parts = line.split(". ", 1) if ". " in line else line.split(") ", 1)
            topic = parts[0].lstrip("0123456789.-) ")
            desc = parts[1] if len(parts) > 1 else ""
            rows.append({"Topic": topic, "Description": desc[:200], "Keywords": ""})
    return rows

def ai_style_register(text, gemini_key, max_chars=8000):
    """AI analyze style and register. Returns table-friendly structure."""
    prompt = """Analyze this text's style and register. Provide a table with 2 columns: Aspect | Assessment.
Include: Register (formal/informal), Tone, Lexical density, Sentence complexity, Domain, Typical audience."""
    return get_llm_response(prompt, text[:max_chars], gemini_key)


# Specialized analysis presets for Translation Studies datasets
# Categories for UI grouping (optional)
AI_ANALYSIS_CATEGORIES = {
    "Overview": ["Corpus Summary", "Style & Register", "Terminology & Domain"],
    "Industry & Profession": ["Language Industry", "Jobs & Career", "Collaboration & Co-authorship", "Legal & Institutional"],
    "Criticism & Reception": ["Translation Criticism", "Reception & Audience"],
    "Visibility & Identity": ["Translator Visibility", "Gender Analysis"],
    "Cultural & Ideological": ["Ideology & Power", "Cultural Transfer", "Ethical Dimensions", "Taboo & Censorship"],
    "Form & Language": ["Metaphor & Imagery", "Narrative Voice", "Intertextuality", "Source Traces", "Humor & Wordplay", "Dialect & Sociolect"],
    "Theory & Context": ["Paratexts & Peritext", "Retranslation", "Skopos & Function", "Polysystem Position", "Temporal & Historical"],
    "Media & Modes": ["Audiovisual & Subtitling", "Multimodality"],
    "Pedagogy": ["Pedagogy & Training"],
    "Other": ["Custom"],
}

AI_ANALYSIS_PRESETS = {
    "Corpus Summary": {
        "prompt": "Summarize this corpus in 3-5 concise paragraphs for a translation studies researcher. Cover: main themes, register/style, key terminology domains, and any notable patterns. Be specific.",
        "icon": "📝",
    },
    "Style & Register": {
        "prompt": "Analyze this text's style and register. Provide a table: Aspect | Assessment. Include: Register (formal/informal), Tone, Lexical density, Sentence complexity, Domain, Typical audience.",
        "icon": "🎭",
    },
    "Language Industry": {
        "prompt": """Analyze this corpus for LANGUAGE INDUSTRY themes (translation market, localization, LSPs, CAT tools, MT, workflow).
Return a table: Theme | Observations | Evidence/Examples
Focus on: market dynamics, technology adoption, professional practices, quality expectations, client-agency relations.""",
        "icon": "🏢",
    },
    "Jobs & Career": {
        "prompt": """Analyze this text for TRANSLATION JOB MARKET and CAREER themes.
Return a table: Aspect | Findings | Implications
Cover: skills demanded, roles mentioned, working conditions, qualifications, career paths, freelance vs in-house, rates/fees if mentioned.""",
        "icon": "💼",
    },
    "Translation Criticism": {
        "prompt": """Analyze this corpus from a TRANSLATION CRITICISM perspective.
Return a table: Criterion | Assessment | Examples
Include: quality indicators, error types, reception/reader response, fidelity assessment, stylistic choices, cultural adequacy. Reference scholarly frameworks (House, Munday, etc.) where relevant.""",
        "icon": "📚",
    },
    "Translator Visibility": {
        "prompt": """Analyze TRANSLATOR VISIBILITY and attribution in this corpus.
Return a table: Aspect | Evidence | Interpretation
Examine: paratexts (prefaces, notes), translator mentions, voice/agency, invisibility vs visibility (Venuti), self-representation, power relations between author-translator-publisher.""",
        "icon": "👁️",
    },
    "Gender Analysis": {
        "prompt": """Perform a GENDER ANALYSIS of this corpus for translation studies.
Return a table: Dimension | Findings | Examples
Examine: gendered language, representation of genders, inclusivity/exclusion, pronouns, terminology choices, feminist translation strategies if present.""",
        "icon": "⚧",
    },
    "Reception & Audience": {
        "prompt": """Analyze RECEPTION and AUDIENCE aspects in this corpus.
Return a table: Aspect | Evidence | Notes
Cover: target readership, reception cues, cultural positioning, marketing/positioning discourse, reader expectations.""",
        "icon": "👥",
    },
    "Terminology & Domain": {
        "prompt": """Extract and analyze TERMINOLOGY and DOMAIN-SPECIFIC patterns in this corpus.
Return a table: Domain/Term cluster | Terms | Usage pattern
Identify specialized terminology, domain indicators, and how technical terms are used or explained.""",
        "icon": "📖",
    },
    "Ideology & Power": {
        "prompt": """Analyze IDEOLOGY and POWER in this corpus from a translation studies perspective.
Return a table: Dimension | Observation | Evidence
Examine: ideological positioning, power asymmetries, cultural representation, hegemonies, resistance or accommodation strategies.""",
        "icon": "⚖️",
    },
    "Paratexts & Peritext": {
        "prompt": """Analyze PARATEXTS (Genette) in this corpus: prefaces, notes, blurbs, covers, author/translator comments.
Return a table: Paratext type | Content/Function | Significance
Examine peritext (inside the book) vs epitext (outside), who speaks (author, translator, publisher), framing of the translation.""",
        "icon": "📑",
    },
    "Cultural Transfer": {
        "prompt": """Analyze CULTURAL TRANSFER and mediation in this corpus.
Return a table: Element | Source culture | Target treatment | Strategy
Examine: culture-specific items, domestication/foreignization, adaptations, explicitation of cultural references.""",
        "icon": "🌐",
    },
    "Ethical Dimensions": {
        "prompt": """Analyze ETHICAL DIMENSIONS of translation in this corpus.
Return a table: Issue | Manifestation | Ethical consideration
Cover: fidelity, manipulation, censorship, representation of others, responsibility, conflict of interest.""",
        "icon": "✋",
    },
    "Metaphor & Imagery": {
        "prompt": """Analyze METAPHOR and IMAGERY in this corpus from a translation perspective.
Return a table: Metaphor/Image | Function | Translation strategy | Effect
Examine how figurative language is handled, preserved, or altered.""",
        "icon": "🖼️",
    },
    "Narrative Voice": {
        "prompt": """Analyze NARRATIVE VOICE and structure in this corpus.
Return a table: Aspect | Observation | Translation implication
Cover: focalization, point of view, narrator type, temporal structure, how voice is maintained or shifted in translation.""",
        "icon": "🗣️",
    },
    "Intertextuality": {
        "prompt": """Analyze INTERTEXTUALITY and allusion in this corpus.
Return a table: Reference | Source | Function | How handled
Examine: quotations, allusions, generic echoes, how intertexts are signaled or adapted for target readers.""",
        "icon": "🔗",
    },
    "Retranslation": {
        "prompt": """Analyze RETRANSLATION or diachronic aspects in this corpus (if applicable).
Return a table: Aspect | Observation | Interpretation
Cover: multiple versions, temporal distance, norm shifts, why retranslate, differences between versions.""",
        "icon": "🔄",
    },
    "Skopos & Function": {
        "prompt": """Analyze SKOPOS and communicative function (Nord, Reiss, Vermeer) in this corpus.
Return a table: Function/Aspect | Evidence | Notes
Examine: intended purpose, addressee, text type, how function shapes translation choices.""",
        "icon": "🎯",
    },
    "Source Traces": {
        "prompt": """Analyze SOURCE-TEXT TRACES and interference in this corpus.
Return a table: Trace type | Example | Assessment
Examine: calques, loan translations, syntax transfer, foreignizing elements, source-language residue.""",
        "icon": "📎",
    },
    "Polysystem Position": {
        "prompt": """Analyze POLYSYSTEM position (Even-Zohar) of texts in this corpus.
Return a table: Dimension | Observation | Implication
Examine: canonical vs peripheral, center vs periphery, innovation vs conservatism, relation to target literature.""",
        "icon": "📊",
    },
    "Collaboration & Co-authorship": {
        "prompt": """Analyze COLLABORATION, co-translation, or multi-actor translation in this corpus.
Return a table: Aspect | Evidence | Notes
Examine: who is involved, roles, attribution, teamwork dynamics, institutional vs individual.""",
        "icon": "🤝",
    },
    "Humor & Wordplay": {
        "prompt": """Analyze HUMOR and WORDPLAY in this corpus from a translation perspective.
Return a table: Example | Type/Technique | Translation challenge | Strategy used
Examine: puns, idioms, cultural humor, how humor is preserved, compensated, or adapted.""",
        "icon": "😄",
    },
    "Dialect & Sociolect": {
        "prompt": """Analyze DIALECT, SOCIOLECT, and linguistic variation in this corpus.
Return a table: Variant | Function | How rendered | Effect
Examine: regional accents, register shifts, social markers, orthographic representation, target-language equivalents.""",
        "icon": "🗺️",
    },
    "Taboo & Censorship": {
        "prompt": """Analyze TABOO, CENSORSHIP, and sensitive content handling in this corpus.
Return a table: Element | Nature | Treatment | Implication
Examine: bowdlerization, euphemism, omission, domestication of taboo, power/control dynamics.""",
        "icon": "🔇",
    },
    "Audiovisual & Subtitling": {
        "prompt": """Analyze AUDIOVISUAL TRANSLATION or SUBTITLING aspects in this corpus.
Return a table: Aspect | Observation | Constraint/Strategy
Examine: space/time limits, condensation, oral-to-written, culture-specific references, readability, spotting.""",
        "icon": "🎬",
    },
    "Legal & Institutional": {
        "prompt": """Analyze LEGAL and INSTITUTIONAL discourse in this corpus.
Return a table: Dimension | Evidence | Notes
Examine: terminology, formulaic language, authority, contracts, certification, professional standards.""",
        "icon": "⚖️",
    },
    "Multimodality": {
        "prompt": """Analyze MULTIMODAL aspects in this corpus (layout, images, typography, paratextual design).
Return a table: Mode | Function | Interaction with text | Translation implication
Examine how non-verbal elements shape meaning and how they are (or aren't) accounted for in translation.""",
        "icon": "🖼️",
    },
    "Pedagogy & Training": {
        "prompt": """Analyze PEDAGOGICAL or TRAINING aspects for translator education.
Return a table: Aspect | Finding | Pedagogical use
Examine: exemplary patterns, error types, competencies reflected, suitable for teaching/learning translation.""",
        "icon": "📗",
    },
    "Temporal & Historical": {
        "prompt": """Analyze TEMPORAL and HISTORICAL dimensions in this corpus.
Return a table: Aspect | Evidence | Interpretation
Examine: diachronic shifts, archaisms, contemporary usage, historical references, period style.""",
        "icon": "📅",
    },
    "Custom": {
        "prompt": None,  # User provides full prompt via custom_instructions
        "icon": "✏️",
    },
}


def ai_specialized_analysis(text, analysis_type, gemini_key, custom_instructions=None, max_chars=12000):
    """
    Run a specialized AI analysis. analysis_type = key in AI_ANALYSIS_PRESETS.
    custom_instructions: optional user text appended to the prompt (e.g. "Focus on literary translations").
    For "Custom" type, custom_instructions IS the full prompt.
    """
    preset = AI_ANALYSIS_PRESETS.get(analysis_type)
    if not preset:
        return f"Unknown analysis type: {analysis_type}"
    if analysis_type == "Custom":
        prompt = str(custom_instructions or "").strip()
        if not prompt:
            return "**Custom analysis:** Enter your analysis prompt in the custom instructions box."
    else:
        prompt = preset["prompt"]
        if custom_instructions and str(custom_instructions).strip():
            prompt += f"\n\n**Additional instructions for this dataset:** {custom_instructions.strip()}"
    return get_llm_response(prompt, text[:max_chars], gemini_key)

def ai_translation_universals(aligned_pairs, gemini_key, max_pairs=15):
    """Analyze translation universals: explicitation, simplification, normalization, etc."""
    if not aligned_pairs:
        return "No aligned pairs to analyze."
    pairs_text = "\n".join([f"{i+1}. SRC: {p.get('Source','')[:150]} | TGT: {p.get('Target','')[:150]}" 
                            for i, p in enumerate(aligned_pairs[:max_pairs])])
    prompt = """Analyze these source-target translation pairs for TRANSLATION UNIVERSALS (Baker 1993, Chesterman 2004).
For each universal, indicate if present (YES/NO) and give 1-2 brief examples:
1. EXPLICITATION: Target is more explicit than source
2. SIMPLIFICATION: Target uses simpler/shorter vocabulary or syntax
3. NORMALIZATION: Target conforms to target-language conventions
4. LEVELLING OUT: Reduction of stylistic variation
5. UNIQUE ITEMS: Under-representation of target-language-specific features
Format as a clear bullet-point report suitable for a research paper."""
    return get_llm_response(prompt, pairs_text, gemini_key)

def ai_label_strategies(aligned_pairs, gemini_key, max_pairs=15):
    """Label each translation pair with strategy (domestication, explicitation, etc.)."""
    if not aligned_pairs:
        return []
    pairs_text = "\n".join([f"{i+1}. SOURCE: {p.get('Source','')} | TARGET: {p.get('Target','')}" 
                            for i, p in enumerate(aligned_pairs[:max_pairs])])
    prompt = """For each numbered pair below, identify the PRIMARY translation strategy. Use exactly one of: Domestication, Foreignization, Explicitation, Implicitation, Literal, Omission, Addition, Modulation, Generalization, Specification.
Return ONLY a numbered list: one strategy per line, e.g. "1. Domestication" """
    raw = get_llm_response(prompt, pairs_text, gemini_key)
    labels = []
    for line in raw.strip().split("\n"):
        line = line.strip()
        if "." in line:
            try:
                idx = int(line.split(".")[0].strip())
                strat = line.split(".", 1)[1].strip() if "." in line else line
                labels.append(strat)
            except ValueError:
                labels.append(line)
    while len(labels) < len(aligned_pairs[:max_pairs]):
        labels.append("—")
    return labels[:max_pairs]

def align_sentences_llm(src, tgt, gemini_key):
    # Simple sentence split + embedding match + LLM refinement
    src_sents = [s.strip() for s in src.split('.') if len(s.strip()) > 15]
    tgt_sents = [s.strip() for s in tgt.split('.') if len(s.strip()) > 15]
    
    if not src_sents or not tgt_sents:
        return [{"Source": src[:200], "Target": tgt[:200], "Similarity": 0.0}]
    
    src_emb = get_embeddings(src_sents)
    tgt_emb = get_embeddings(tgt_sents)
    
    alignments = []
    for i, s in enumerate(src_sents):
        sims = np.dot(tgt_emb, src_emb[i])
        best = np.argmax(sims)
        alignments.append({"Source": s, "Target": tgt_sents[best], "Similarity": round(float(sims[best]), 3)})
    
    return alignments
