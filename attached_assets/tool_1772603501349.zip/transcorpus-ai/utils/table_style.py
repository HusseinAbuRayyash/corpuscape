"""Table styling helpers for TransCorpus AI."""
import pandas as pd
import streamlit as st

# Matplotlib colormaps for pandas background_gradient (table styling)
TABLE_CMAPS = ["GnBu", "Blues", "Greens", "Purples", "Oranges", "RdYlGn", "BuPu", "YlOrRd", "PuBu", "coolwarm", "viridis", "plasma"]

# Header background color presets (warm, eye-friendly)
HEADER_COLORS = {
    "Default": "#F5F4F2",
    "Teal": "#d1fae5",
    "Blue": "#dbeafe",
    "Green": "#dcfce7",
    "Purple": "#f3e8ff",
    "Amber": "#fef3c7",
}

# Zebra striping (alternate row) colors
ZEBRA_COLORS = {
    "None": None,
    "Light gray": "#FAF9F8",
    "Teal tint": "#ecfdf5",
    "Blue tint": "#f0f9ff",
    "Lavender": "#faf5ff",
}


def prepare_table(df, columns_to_show=None, exclude_rows=None, key_column=None,
                  add_pct_col=None, add_rank_col=None):
    """
    Prepare table: filter columns/rows, add derived columns.
    - columns_to_show: list of column names to display (None = all)
    - exclude_rows: list of values to exclude from key_column (e.g. terms to hide)
    - add_pct_col: name of freq column to add % of total (e.g. "Frequency")
    - add_rank_col: name of freq column for ranking (adds "Rank" column)
    """
    out = df.copy()
    if exclude_rows and key_column and key_column in out.columns:
        out = out[~out[key_column].isin(exclude_rows)]
    if add_pct_col and add_pct_col in out.columns:
        total = out[add_pct_col].sum()
        out = out.copy()
        out["%"] = (out[add_pct_col] / total * 100).round(2) if total else 0
    if add_rank_col and add_rank_col in out.columns:
        out = out.copy()
        out["Rank"] = range(1, len(out) + 1)
    if columns_to_show:
        valid = [c for c in columns_to_show if c in out.columns]
        if valid:
            out = out[valid]
    return out


def style_table_full(df, gradient_cols=None, cmap="GnBu", header_color="#F5F4F2",
                     zebra_color=None, highlight_col=None, highlight_bg="#d1fae5"):
    """
    Apply full table styling: gradient, header, zebra striping, column highlight.
    - gradient_cols: list of numeric columns for gradient
    - header_color: hex for header background
    - zebra_color: hex for alternate rows (None to disable)
    - highlight_col: column name to highlight (e.g. Match in concordance)
    """
    sty = df.style
    if gradient_cols:
        valid = [c for c in gradient_cols if c in df.columns]
        if valid:
            sty = sty.background_gradient(subset=valid, cmap=cmap)
    styles = []
    if header_color:
        styles.append({"selector": "th", "props": [("background-color", header_color), ("font-weight", "600")]})
    if zebra_color:
        styles.append({"selector": "tbody tr:nth-child(even)", "props": [("background-color", zebra_color)]})
    if styles:
        sty = sty.set_table_styles(styles)
    if highlight_col and highlight_col in df.columns:
        def _hl(val):
            return "background-color: %s; font-weight: bold" % highlight_bg if val and str(val).strip() else ""
        sty = sty.map(_hl, subset=[highlight_col])
    return sty


def inject_css():
    """Inject comfy UI styling (Source Sans 3, warm colors)."""
    st.markdown("""
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Typography - Source Sans 3 */
        .stApp, .main .block-container, [data-testid="stSidebar"] { 
            font-family: 'Source Sans 3', -apple-system, BlinkMacSystemFont, sans-serif !important; 
        }
        h1, h2, h3 { font-family: 'Source Sans 3', sans-serif !important; }
        h1 { color: #1C1917 !important; font-weight: 600 !important; font-size: 26px !important; letter-spacing: -0.02em !important; line-height: 1.25 !important; }
        h2 { color: #1C1917 !important; font-weight: 600 !important; font-size: 26px !important; line-height: 1.25 !important; }
        h3 { color: #1C1917 !important; font-weight: 600 !important; font-size: 18px !important; line-height: 1.3 !important; }
        [data-testid="stMarkdown"] p, .stCaption { color: #57534E !important; font-size: 16px !important; line-height: 1.6 !important; }
        
        /* Main container */
        .main .block-container { padding: 2rem 1.5rem !important; max-width: 1120px; }
        
        /* Tabs - primary #0F8278 */
        .stTabs [data-baseweb="tab-list"] { 
            background: transparent !important; border-bottom: 2px solid #E7E5E4 !important;
            padding: 0 0 0 4px !important; gap: 0 !important;
        }
        .stTabs [data-baseweb="tab"] { 
            border-radius: 8px 8px 0 0 !important; padding: 12px 20px !important; font-weight: 600;
            background: transparent !important; color: #57534E !important;
        }
        .stTabs [data-baseweb="tab"]:hover { color: #1C1917 !important; background: #F5F4F2 !important; }
        .stTabs [aria-selected="true"] { 
            background: #FDFCFB !important; color: #0F8278 !important;
            border: 1px solid #E7E5E4; border-bottom: none; margin-bottom: -2px; box-shadow: 0 -2px 8px rgba(0,0,0,0.04);
        }
        
        /* File uploader */
        [data-testid="stFileUploader"] { border-radius: 16px !important; overflow: hidden; }
        [data-testid="stFileUploader"] div[data-testid="stFileUploaderDropzone"],
        div[data-testid="stFileUploader"] {
            border: 2px dashed #E7E5E4 !important; border-radius: 16px !important;
            background: linear-gradient(180deg, #FDFCFB 0%, #F5F4F2 100%) !important;
            transition: all 0.2s ease !important;
        }
        
        /* DataFrames - lighter borders */
        div[data-testid="stDataFrame"] { 
            border-radius: 14px !important; overflow: hidden !important; 
            box-shadow: 0 1px 4px rgba(0,0,0,0.05) !important;
            border: 1px solid #E7E5E4 !important;
        }
        
        /* Expanders */
        div[data-testid="stExpander"] { 
            border: 1px solid #E7E5E4 !important; border-radius: 14px !important;
            background: #FDFCFB !important; margin-bottom: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }
        details summary { font-weight: 600 !important; color: #1C1917 !important; padding: 0.5rem 0 !important; }
        
        /* Metrics */
        div[data-testid="metric-container"] { 
            background: linear-gradient(145deg, #FDFCFB 0%, #ecfdf5 50%, #d1fae5 30%) !important; 
            padding: 1.5rem !important; border-radius: 14px !important; 
            border: 1px solid rgba(15, 130, 120, 0.3) !important;
            box-shadow: 0 1px 4px rgba(15, 130, 120, 0.08);
        }
        [data-testid="stMetricValue"] { font-weight: 700 !important; color: #0F8278 !important; font-size: 1.5rem !important; }
        [data-testid="stMetricLabel"] { font-weight: 500 !important; color: #57534E !important; }
        
        /* Buttons */
        .stButton > button { 
            border-radius: 12px !important; font-weight: 600 !important;
            transition: all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
        }
        .stButton > button[kind="primary"] { 
            background: #0F8278 !important; border-color: #0F8278 !important;
            box-shadow: 0 2px 8px rgba(15, 130, 120, 0.25);
        }
        .stButton > button[kind="primary"]:hover { 
            transform: translateY(-2px); box-shadow: 0 4px 12px rgba(15, 130, 120, 0.3) !important;
        }
        .stButton > button:not([kind="primary"]):hover { background: #F5F4F2 !important; }
        
        /* Alerts */
        .stSuccess, .stInfo { border-radius: 14px !important; border-left: 5px solid #0F8278 !important; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
        .stWarning { border-radius: 14px !important; border-left: 5px solid #f59e0b !important; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
        .stError { border-radius: 14px !important; border-left: 5px solid #ef4444 !important; }
        
        /* Charts */
        .stPlotlyChart { border-radius: 14px !important; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.05) !important; }
        
        /* Sidebar */
        [data-testid="stSidebar"] { 
            background: #FAF9F8 !important; 
            border-right: 1px solid #E7E5E4 !important;
        }
        [data-testid="stSidebar"] h2 { font-size: 1.1rem !important; }
        [data-testid="stSidebar"] h3 { font-size: 1rem !important; font-weight: 600 !important; color: #1C1917 !important; margin-bottom: 0.5rem !important; }
        
        [data-testid="stSidebar"] [data-testid="stPageLink"] a,
        [data-testid="stSidebar"] a[data-testid="stPageLink"] {
            border-radius: 12px !important; padding: 12px 16px !important; margin: 4px 0 !important;
            font-weight: 500 !important; transition: all 0.2s ease !important;
        }
        [data-testid="stSidebar"] [data-testid="stPageLink"]:hover a,
        [data-testid="stSidebar"] [data-testid="stPageLink"] a:hover { 
            background: rgba(15, 130, 120, 0.08) !important; color: #0F8278 !important;
        }
        [data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-current="page"] {
            background: rgba(15, 130, 120, 0.12) !important;
            color: #0F8278 !important; font-weight: 600 !important;
        }
        [data-testid="stSidebar"] hr { margin: 1rem 0 !important; border-color: #E7E5E4 !important; }
        
        hr { border: none; border-top: 1px solid #E7E5E4; margin: 1.5rem 0; }
        
        .stTextInput input:focus, .stSelectbox > div:focus-within { 
            box-shadow: 0 0 0 3px rgba(15, 130, 120, 0.15) !important; 
        }
        .stTextInput input, .stSelectbox > div, .stMultiSelect > div { border-radius: 12px !important; }
        
        ::selection { background: rgba(15, 130, 120, 0.2); }
        
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #F5F4F2; border-radius: 4px; }
        ::-webkit-scrollbar-thumb { background: #d6d3d1; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #a8a29e; }
    </style>
    """, unsafe_allow_html=True)

def style_table(df, gradient_col=None, cmap="GnBu"):
    """Apply gradient to a numeric column if specified. cmap: GnBu, Blues, Greens, etc."""
    if gradient_col and gradient_col in df.columns:
        return df.style.background_gradient(subset=[gradient_col], cmap=cmap)
    return df.style

def style_table_multi(df, gradient_cols=None, cmap="GnBu"):
    """Apply gradient to multiple numeric columns."""
    if gradient_cols:
        valid = [c for c in gradient_cols if c in df.columns]
        if valid:
            return df.style.background_gradient(subset=valid, cmap=cmap)
    return df.style
