"""Shared sidebar: nav, settings, citation. Lighter styling, icons, active pill."""
import streamlit as st

PAGES = [
    ("app.py", "App", "🏠"),
    ("pages/1_Monolingual.py", "Monolingual", "📖"),
    ("pages/2_Bilingual.py", "Bilingual", "🌐"),
    ("pages/3_AI_Insights.py", "AI Insights", "🤖"),
]


def render_sidebar(active: str | None = None):
    """Render nav + collapsible settings. Call at start of each page. Pass active for pill highlight."""
    st.markdown("""
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
    section[data-testid="stSidebar"] { background: #FAF9F8 !important; font-family: 'Source Sans 3', sans-serif !important; }
    section[data-testid="stSidebar"] [data-testid="stSidebarContent"] { padding-top: 0.75rem; }
    section[data-testid="stSidebar"] a { 
        border-radius: 0.5rem; padding: 0.4rem 0.6rem; 
        transition: background 0.2s ease, color 0.2s ease; 
    }
    section[data-testid="stSidebar"] a:hover { background: rgba(0,0,0,0.04) !important; }
    section[data-testid="stSidebar"] .nav-pill { 
        display: inline-block; padding: 0.4rem 0.6rem; border-radius: 0.5rem; 
        background: rgba(15, 130, 120, 0.12); color: #0F8278; font-weight: 500;
    }
    section[data-testid="stSidebar"] .stExpander summary { 
        font-weight: 500; padding: 0.4rem 0; 
        border: none; background: transparent !important; 
    }
    </style>
    """, unsafe_allow_html=True)

    st.sidebar.markdown("### TransCorpus")
    st.sidebar.markdown("---")

    for path, label, icon in PAGES:
        if active and label == active:
            st.sidebar.markdown(f'<span class="nav-pill">{icon} {label}</span>', unsafe_allow_html=True)
        else:
            try:
                st.page_link(path, label=label, icon=icon)
            except st.errors.StreamlitPageNotFoundError:
                st.sidebar.caption(f"{icon} {label} *(unavailable)*")

    st.sidebar.markdown("---")

    with st.sidebar.expander("Settings", expanded=False):
        st.caption("[Get free Gemini key](https://aistudio.google.com/app/apikey)")
        gemini_key = st.text_input("Gemini API Key", type="password", value=st.session_state.get("gemini_key", ""), key="sidebar_gemini")
        openai_key = st.text_input("OpenAI API Key (optional)", type="password", value=st.session_state.get("openai_key", ""), key="sidebar_openai")

    if gemini_key:
        st.session_state.gemini_key = gemini_key.strip()
    if openai_key:
        st.session_state.openai_key = openai_key.strip()
