# TransCorpus AI — Landing

React + Tailwind landing page for TransCorpus AI. Premium, research-grade interface.

## Run

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Build

```bash
npm run build
```

## Track links

By default, track buttons link to the Streamlit app at `http://localhost:8501`.  
Set `VITE_STREAMLIT_URL` when building for production:

```bash
VITE_STREAMLIT_URL=https://your-streamlit-app.com npm run build
```

## Structure

- `Layout.tsx` — Page shell, top bar, background
- `TopBar.tsx` — Minimal header (product name, Deploy, menu)
- `HeroSection.tsx` — Centered hero with title and subtitle
- `TrackCard.tsx` — Card with icon, description, example, action
- `TrackGrid.tsx` — Responsive 3‑column grid of track cards
- `QuickStartAccordion.tsx` — Collapsible tips panel
