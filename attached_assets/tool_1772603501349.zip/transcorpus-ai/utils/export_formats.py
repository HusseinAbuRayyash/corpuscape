"""Export formats for translation studies: TMX, TBX, Research Report."""
import io
import zipfile
from datetime import datetime

def export_tmx(aligned_pairs, source_lang="en", target_lang="en"):
    """Export aligned pairs to TMX 1.4 (Translation Memory eXchange) for CAT tools."""
    header = f'''<?xml version="1.0" encoding="UTF-8"?>
<tmx version="1.4">
  <header creationtool="TransCorpus AI" creationtoolversion="1.0" datatype="plaintext"
          segtype="sentence" adminlang="en" srclang="{source_lang}" o-tmf="unknown">
    <note>Exported from TransCorpus AI - ATISA 2026</note>
  </header>
  <body>
'''
    body = ""
    for pair in aligned_pairs:
        src = str(pair.get("Source", "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        tgt = str(pair.get("Target", "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
        body += f'''    <tu>
      <tuv xml:lang="{source_lang}"><seg>{src}</seg></tuv>
      <tuv xml:lang="{target_lang}"><seg>{tgt}</seg></tuv>
    </tu>
'''
    return header + body + "  </body>\n</tmx>"

def export_research_report(mono_stats=None, mono_keywords=None, bilingual_df=None, ai_summary=None, ai_analyses=None):
    """Generate an academic-ready research report (Markdown)."""
    lines = [
        "# TransCorpus AI – Research Report",
        "",
        f"*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*",
        "",
        "---",
        "",
        "## 1. Methodology",
        "",
        "This report was produced using TransCorpus AI, an AI-powered corpus analysis tool for translation studies. "
        "Analyses include: corpus statistics, keyword extraction, n-gram analysis, concordancing, and (for bilingual corpora) "
        "sentence alignment with translation strategy labeling.",
        "",
        "**Tool citation:** TransCorpus AI. (2026). ATISA Pre-Workshop. Hussein Abu-Rayyash.",
        "",
        "---",
        "",
    ]
    if mono_stats:
        lines.extend([
            "## 2. Monolingual Corpus Statistics",
            "",
            "| Metric | Value |",
            "|--------|-------|",
        ])
        for k, v in mono_stats.items():
            lines.append(f"| {k} | {v} |")
        lines.extend(["", ""])
    if mono_keywords is not None and len(mono_keywords) > 0:
        lines.extend([
            "## 3. Top Keywords",
            "",
            "| Term | Frequency |",
            "|------|-----------|",
        ])
        for _, row in mono_keywords.head(20).iterrows():
            lines.append(f"| {row['Term']} | {row['Frequency']} |")
        lines.extend(["", ""])
    if bilingual_df is not None and len(bilingual_df) > 0:
        lines.extend([
            "## 4. Bilingual Analysis",
            "",
            f"- **Aligned pairs:** {len(bilingual_df)}",
            "",
        ])
        if "Similarity" in bilingual_df.columns:
            lines.append(f"- **Average similarity score:** {bilingual_df['Similarity'].mean():.3f}")
        if "Strategy" in bilingual_df.columns:
            strat_counts = bilingual_df["Strategy"].value_counts()
            lines.append("- **Strategy distribution:**")
            for s, c in strat_counts.head(10).items():
                if s and str(s).strip() != "—":
                    lines.append(f"  - {s}: {c}")
        lines.extend(["", ""])
    ai_section_num = 5
    if ai_summary:
        lines.extend([
            f"## {ai_section_num}. AI Corpus Summary",
            "",
            ai_summary,
            "",
            "---",
            "",
        ])
        ai_section_num += 1
    if ai_analyses:
        for name, content in ai_analyses:
            if content and str(content).strip():
                lines.extend([
                    f"## {ai_section_num}. AI Analysis: {name}",
                    "",
                    str(content).strip(),
                    "",
                    "---",
                    "",
                ])
                ai_section_num += 1
    lines.extend([
        "## References",
        "",
        "TransCorpus AI. (2026). AI-Powered Corpus Lab for Translation Studies. ATISA Pre-Workshop. "
        "https://github.com/ [or your deployment URL]",
        "",
    ])
    return "\n".join(lines)
