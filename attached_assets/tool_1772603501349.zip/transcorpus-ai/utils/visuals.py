"""Beautiful, colorful charts and styling for TransCorpus AI."""
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd

# Modern color palettes
PALETTE_KEYWORDS = px.colors.qualitative.Set3  # Soft pastels
PALETTE_NGRAMS = px.colors.sequential.Teal_r
PALETTE_GRADIENT = ["#0d9488", "#14b8a6", "#2dd4bf", "#5eead4", "#99f6e4", "#ccfbf1"]
PALETTE_ACCENT = ["#0891b2", "#0e7490", "#155e75", "#164e63"]

# Named color palettes for user selection (Plotly continuous scales)
CHART_PALETTES = {
    "Teal": ["#ccfbf1", "#0d9488", "#0f766e"],
    "Blues": "Blues",
    "Greens": "Greens",
    "Purples": "Purples",
    "Viridis": "Viridis",
    "Plasma": "Plasma",
    "Inferno": "Inferno",
    "Magma": "Magma",
    "Cividis": "Cividis",
    "Oranges": "Oranges",
    "Reds": "Reds",
    "BuPu": "BuPu",
    "GnBu": "GnBu",
    "YlOrRd": "YlOrRd",
}
COLOR_BG = "#f8fafc"
COLOR_PAPER = "#ffffff"
COLOR_GRID = "#e2e8f0"
FONT_FAMILY = "Inter, system-ui, sans-serif"

def _apply_theme(fig):
    """Apply consistent modern theme to all figures."""
    fig.update_layout(
        template="plotly_white",
        paper_bgcolor=COLOR_PAPER,
        plot_bgcolor=COLOR_BG,
        font=dict(family=FONT_FAMILY, size=12),
        margin=dict(l=50, r=50, t=60, b=50),
        hoverlabel=dict(bgcolor="#0f172a", font=dict(color="white")),
        xaxis=dict(gridcolor=COLOR_GRID, showline=True, linewidth=1, linecolor="#cbd5e1"),
        yaxis=dict(gridcolor=COLOR_GRID, showline=True, linewidth=1, linecolor="#cbd5e1"),
        title=dict(font=dict(size=18, color="#1e293b"), x=0.5, xanchor="center"),
        legend=dict(bgcolor="rgba(255,255,255,0.9)", bordercolor="#e2e8f0"),
        bargap=0.25,
        bargroupgap=0.1,
    )
    fig.update_traces(marker_line_width=0)
    return fig

def _resolve_palette(palette_key):
    """Resolve palette key to Plotly-compatible scale (string or list)."""
    if palette_key and palette_key in CHART_PALETTES:
        return CHART_PALETTES[palette_key]
    return CHART_PALETTES["Teal"]

def _palette_to_color(palette_key):
    """Get a single hex color for line/area charts from palette."""
    scale = _resolve_palette(palette_key)
    if isinstance(scale, (list, tuple)) and scale:
        return scale[0] if isinstance(scale[0], str) else "#0d9488"
    # Named scale - use a representative color
    fallbacks = {"Teal": "#0d9488", "Blues": "#3182bd", "Greens": "#31a354", "Purples": "#756bb1",
                 "Viridis": "#440154", "Plasma": "#0d0887", "Oranges": "#e6550d", "Reds": "#de2d26"}
    return fallbacks.get(palette_key if palette_key in CHART_PALETTES else "Teal", "#0d9488")

def plot_keyword_chart(df, chart_type="bar", title="📊 Top Keywords", n_bars=15, show_labels=True, show_grid=True, color_palette="Teal", exclude=None):
    """Unified keyword chart: bar, hbar, line, or area."""
    df_plot = df.head(n_bars).copy()
    if exclude:
        df_plot = df_plot[~df_plot["Term"].isin(exclude)]
    if df_plot.empty:
        return go.Figure().add_annotation(text="No data to display", showarrow=False)
    scale = _resolve_palette(color_palette)
    xcol, ycol = "Term", "Frequency"
    bar_kw = dict(title=title, color="Frequency", color_continuous_scale=scale)
    if chart_type == "hbar":
        fig = px.bar(df_plot, y=xcol, x=ycol, orientation="h", text=ycol if show_labels else None, **bar_kw)
    elif chart_type == "line":
        fig = px.line(df_plot, x=xcol, y=ycol, markers=True, title=title)
        base_color = _palette_to_color(color_palette)
        fig.update_traces(line=dict(width=3, color=base_color), marker=dict(size=10, color=base_color))
    elif chart_type == "area":
        fig = px.area(df_plot, x=xcol, y=ycol, title=title)
        base_color = _palette_to_color(color_palette)
        fig.update_traces(line=dict(width=1, color=base_color))
    else:
        fig = px.bar(df_plot, x=xcol, y=ycol, text=ycol if show_labels else None, **bar_kw)
    if show_labels and chart_type in ("bar", "hbar"):
        fig.update_traces(textposition="outside" if chart_type == "bar" else "outside", textfont=dict(size=11))
    fig.update_layout(
        showlegend=False, coloraxis_showscale=False,
        xaxis=dict(showgrid=show_grid), yaxis=dict(showgrid=show_grid),
    )
    if chart_type == "hbar":
        fig.update_layout(xaxis=dict(showgrid=show_grid), yaxis=dict(showgrid=show_grid, autorange="reversed"))
    return _apply_theme(fig)

def plot_keyword_bars(df, title="📊 Top Keywords", n_bars=15, show_labels=True, show_grid=True, color_scale=None, exclude=None):
    """Top keywords bar chart. Wrapper for plot_keyword_chart."""
    pal = color_scale if isinstance(color_scale, str) and color_scale in CHART_PALETTES else "Teal"
    return plot_keyword_chart(df, chart_type="bar", title=title, n_bars=n_bars, show_labels=show_labels,
                              show_grid=show_grid, color_palette=pal, exclude=exclude)

def plot_ngram_chart(df, chart_type="bar", title="N-grams", n_bars=15, show_labels=True, show_grid=True, x_angle=-45, color_palette="Teal", exclude=None):
    """Unified n-gram chart: bar, hbar, line, or area."""
    df_plot = df.head(n_bars).copy()
    if exclude:
        df_plot = df_plot[~df_plot["N-gram"].isin(exclude)]
    if df_plot.empty:
        return go.Figure().add_annotation(text="No data to display", showarrow=False)
    scale = _resolve_palette(color_palette)
    xcol, ycol = "N-gram", "Frequency"
    bar_kw = dict(title=title, color="Frequency", color_continuous_scale=scale)
    if chart_type == "hbar":
        fig = px.bar(df_plot, y=xcol, x=ycol, orientation="h", text=ycol if show_labels else None, **bar_kw)
    elif chart_type == "line":
        fig = px.line(df_plot, x=xcol, y=ycol, markers=True, title=title)
        base_color = _palette_to_color(color_palette)
        fig.update_traces(line=dict(width=3, color=base_color), marker=dict(size=10, color=base_color))
    elif chart_type == "area":
        fig = px.area(df_plot, x=xcol, y=ycol, title=title)
        base_color = _palette_to_color(color_palette)
        fig.update_traces(line=dict(width=1, color=base_color))
    else:
        fig = px.bar(df_plot, x=xcol, y=ycol, text=ycol if show_labels else None, **bar_kw)
    if show_labels and chart_type in ("bar", "hbar"):
        fig.update_traces(textposition="outside", textfont=dict(size=11))
    fig.update_layout(
        showlegend=False, coloraxis_showscale=False,
        xaxis=dict(tickangle=x_angle, showgrid=show_grid),
        yaxis=dict(showgrid=show_grid),
    )
    if chart_type == "hbar":
        fig.update_layout(xaxis=dict(showgrid=show_grid), yaxis=dict(showgrid=show_grid, autorange="reversed"))
    return _apply_theme(fig)

def plot_ngram_bars(df, title="N-grams", n_bars=15, show_labels=True, show_grid=True, x_angle=-45, exclude=None):
    """N-gram bar chart. Wrapper for plot_ngram_chart."""
    return plot_ngram_chart(df, chart_type="bar", title=title, n_bars=n_bars, show_labels=show_labels,
                           show_grid=show_grid, x_angle=x_angle, exclude=exclude)

def create_radar_chart(labels, source_vals, target_vals):
    """Radar chart for source vs target comparison."""
    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=source_vals, theta=labels, fill='toself',
        name='Source', line=dict(color='#0891b2'), fillcolor='rgba(8,145,178,0.4)'
    ))
    fig.add_trace(go.Scatterpolar(
        r=target_vals, theta=labels, fill='toself',
        name='Target', line=dict(color='#0d9488'), fillcolor='rgba(13,148,136,0.4)'
    ))
    fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 10], gridcolor=COLOR_GRID)),
        showlegend=True,
        paper_bgcolor=COLOR_PAPER,
        font=dict(family=FONT_FAMILY),
    )
    return fig

PIE_PALETTES = {
    "Teal": px.colors.sequential.Teal_r,
    "Blues": px.colors.sequential.Blues_r,
    "Greens": px.colors.sequential.Greens_r,
    "Purples": px.colors.sequential.Purples_r,
    "Oranges": px.colors.sequential.Oranges_r,
    "Reds": px.colors.sequential.Reds_r,
    "Viridis": px.colors.sequential.Viridis,
    "Plasma": px.colors.sequential.Plasma,
    "Inferno": px.colors.sequential.Inferno,
    "Magma": px.colors.sequential.Magma,
    "Cividis": px.colors.sequential.Cividis,
    "GnBu": px.colors.sequential.GnBu_r,
    "BuPu": px.colors.sequential.BuPu_r,
    "YlOrRd": px.colors.sequential.YlOrRd_r,
}

def plot_keyword_pie(df, top_n=10, title="📊 Top Keywords (Donut)", show_legend=False, hole=0.5, color_palette="Teal"):
    """Donut chart for top keywords. All params editable."""
    df_plot = df.head(top_n)
    colors = PIE_PALETTES.get(color_palette, PIE_PALETTES["Teal"])
    fig = go.Figure(data=[go.Pie(
        labels=df_plot["Term"], values=df_plot["Frequency"],
        hole=hole, marker=dict(colors=colors),
        textinfo="label+percent", textposition="outside",
    )])
    fig.update_layout(
        title=title,
        showlegend=show_legend,
        paper_bgcolor=COLOR_PAPER,
        font=dict(family=FONT_FAMILY),
        margin=dict(t=50, b=30),
        annotations=[dict(text="", showarrow=False)],
        height=400,
    )
    return fig

WC_COLORMAPS = ("Teal", "Blues", "Greens", "Purples", "viridis", "plasma", "cool", "YlOrRd")
# WordCloud uses matplotlib colormaps; "Teal" is not valid, so we map to viridis
WC_CMAP_MAP = {"Teal": "viridis", "Blues": "Blues", "Greens": "Greens", "Purples": "Purples",
               "viridis": "viridis", "plasma": "plasma", "cool": "cool", "YlOrRd": "YlOrRd"}

def generate_wordcloud_image(text, max_words=80, width=800, height=400, colormap="Teal"):
    """Generate wordcloud as PIL Image. Returns bytes for display."""
    try:
        from wordcloud import WordCloud
        import io
        # Map display names to valid matplotlib colormaps
        mpl_cmap = WC_CMAP_MAP.get(colormap, "viridis")
        # Simple pre-process: lowercase, keep alphanumeric-ish words
        words = " ".join(w for w in text.split() if len(w) > 2)
        if not words.strip():
            return None
        wc = WordCloud(
            width=width, height=height, max_words=max_words,
            background_color="white", colormap=mpl_cmap,
            contour_width=0, contour_color="#0d9488",
            min_font_size=10,
        ).generate(words)
        img = wc.to_image()
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return None

def styled_stats_table(df, cmap="Blues"):
    """Return styled stats DataFrame with subtle gradient. cmap: GnBu, Blues, Greens, etc."""
    if "Value" in df.columns and df["Value"].dtype in ["int64", "float64"]:
        return df.style.background_gradient(subset=["Value"], cmap=cmap, axis=0)
    return df.style.set_properties(**{"text-align": "left"})
