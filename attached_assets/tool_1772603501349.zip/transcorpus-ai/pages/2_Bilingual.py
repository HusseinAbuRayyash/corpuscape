import streamlit as st
import pandas as pd
import io
from utils.corpus import load_files, clean_text
from utils.table_style import inject_css
from utils.llm import align_sentences_llm, get_llm_response, ai_label_strategies, ai_translation_universals
from utils.export_formats import export_tmx
from utils.sidebar import render_sidebar

st.set_page_config(page_title="TransCorpus AI", page_icon="📖", layout="wide")
render_sidebar(active="Bilingual")
inject_css()
st.markdown("# 🌐 Bilingual Track")
st.caption("Parallel corpus alignment, translation strategies, universals, TMX export for CAT tools")

col1, col2 = st.columns(2)

with col1:
    src_files = st.file_uploader("Source files (.txt, .docx, .pdf, .xlsx, .xls)", accept_multiple_files=True, type=["txt","docx","pdf","xlsx","xls"], key="src")
with col2:
    tgt_files = st.file_uploader("Target files (.txt, .docx, .pdf, .xlsx, .xls)", accept_multiple_files=True, type=["txt","docx","pdf","xlsx","xls"], key="tgt")

if src_files and tgt_files and st.button("Align & Analyze"):
    src_text = clean_text(load_files(src_files))
    tgt_text = clean_text(load_files(tgt_files))
    
    with st.spinner("Aligning sentences..."):
        aligned = align_sentences_llm(src_text, tgt_text, st.session_state.get("gemini_key"))
        st.session_state.aligned_df = pd.DataFrame(aligned)
    
    # AI strategy labels per pair
    gemini_key = st.session_state.get("gemini_key")
    if gemini_key:
        with st.spinner("AI labeling translation strategies..."):
            pairs_list = st.session_state.aligned_df.to_dict("records")
            labels = ai_label_strategies(pairs_list, gemini_key)
            n = len(st.session_state.aligned_df)
            st.session_state.aligned_df["Strategy"] = (labels + [""] * n)[:n]
    
    # Metrics & length ratio
    df_al = st.session_state.aligned_df
    src_words = sum(len(str(s).split()) for s in df_al["Source"])
    tgt_words = sum(len(str(t).split()) for t in df_al["Target"])
    ratio = tgt_words / src_words if src_words > 0 else 0
    al1, al2, al3, al4 = st.columns(4)
    with al1:
        st.metric("Aligned Pairs", len(df_al))
    with al2:
        avg_sim = df_al["Similarity"].mean() if "Similarity" in df_al.columns else 0
        st.metric("Avg Similarity", f"{avg_sim:.3f}")
    with al3:
        strat_count = len([s for s in (df_al["Strategy"] if "Strategy" in df_al.columns else []) if s and str(s).strip() != "—"])
        st.metric("Strategies Labeled", strat_count)
    with al4:
        st.metric("Length Ratio (T/S)", f"{ratio:.2f}", help="Target words / Source words (expansion if >1)")

    st.subheader("📋 Aligned Pairs")
    with st.expander("✏️ Customize table", expanded=False):
        al_rows = st.slider("Rows to show", 5, 100, 50, key="al_rows")
        al_grad = st.checkbox("Show gradient on Similarity", True, key="al_grad")
    df_al_d = st.session_state.aligned_df.head(al_rows)
    if "Similarity" in df_al_d.columns and al_grad:
        st.dataframe(df_al_d.style.background_gradient(subset=["Similarity"], cmap="GnBu"), use_container_width=True)
    else:
        st.dataframe(df_al_d, use_container_width=True)
    
    # Download: CSV, Excel, TMX
    df_dl = st.session_state.aligned_df
    csv = df_dl.to_csv(index=False).encode("utf-8")
    lc1, lc2 = st.columns(2)
    with lc1:
        src_lang = st.text_input("Source lang (ISO 639-1)", value="en", key="src_lang", help="e.g. en, ar, fr")
    with lc2:
        tgt_lang = st.text_input("Target lang (ISO 639-1)", value="ar", key="tgt_lang")
    col_dl1, col_dl2, col_dl3 = st.columns(3)
    with col_dl1:
        st.download_button("📥 CSV", csv, "aligned_pairs.csv", "text/csv", use_container_width=True)
    with col_dl2:
        try:
            xb = io.BytesIO()
            df_dl.to_excel(xb, index=False, engine="openpyxl")
            st.download_button("📥 Excel", xb.getvalue(), "aligned_pairs.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
        except Exception:
            pass
    with col_dl3:
        tmx = export_tmx(df_dl.to_dict("records"), src_lang, tgt_lang)
        st.download_button("📥 TMX (CAT)", tmx.encode("utf-8"), "translation_memory.tmx", "application/xml", use_container_width=True, help="Import into Trados, MemoQ, etc.")

    st.subheader("Translation Universals (AI)")
    if gemini_key:
        if st.button("Analyze universals (explicitation, simplification…)"):
            with st.expander("Translation universals report", expanded=True):
                universals = ai_translation_universals(df_dl.to_dict("records"), gemini_key)
                st.markdown(universals)

    st.subheader("Translation Strategy Analysis (AI)")
    if gemini_key:
        strategy = get_llm_response("Analyze translation strategies in these pairs (domestication, explicitation, etc.). Summarize dominant strategies.", 
                                   str(st.session_state.aligned_df.head(20)), 
                                   gemini_key)
        st.markdown(strategy)
