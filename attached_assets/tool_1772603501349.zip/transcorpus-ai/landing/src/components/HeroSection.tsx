export function HeroSection() {
  return (
    <section className="animate-hero-fade py-24 text-center">
      <h1 className="font-display text-[48px] font-semibold tracking-tight text-[#111418]">
        TransCorpus AI
      </h1>
      <p className="mt-3 text-[28px] font-semibold text-[#111418]">
        Build, align, and probe corpora with AI.
      </p>
      <p className="mt-2 text-sm font-normal leading-relaxed text-[#5C6670]">
        For Translation Studies research and corpus analysis.
      </p>
    </section>
  );
}
