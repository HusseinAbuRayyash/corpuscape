import streamlit as st
import pandas as pd
from utils.corpus import load_files, clean_text, get_stats
from utils.table_style import inject_css, style_table_full, TABLE_CMAPS
from utils.llm import get_llm_response, ai_specialized_analysis, AI_ANALYSIS_PRESETS, AI_ANALYSIS_CATEGORIES
from utils.sidebar import render_sidebar

st.set_page_config(page_title="TransCorpus AI", page_icon="📖", layout="wide")
render_sidebar(active="AI Insights")
inject_css()
st.markdown("# 🤖 AI Insights Lab")
st.caption("31 specialized analysis types — industry, jobs, criticism, visibility, gender, and more. Customizable for each dataset.")

# Use monolingual or bilingual data if available
text = None
if "monolingual_text" in st.session_state:
    text = st.session_state.monolingual_text
elif "aligned_df" in st.session_state:
    df = st.session_state.aligned_df
    text = " ".join(df["Source"].astype(str).tolist() + df["Target"].astype(str).tolist())

if not text:
    st.info("Upload a corpus in **Monolingual Track** or align texts in **Bilingual Track** first.")
else:
    gemini_key = st.session_state.get("gemini_key")
    if not gemini_key:
        st.warning("Add your Gemini API key in the sidebar.")
    else:
        tab0, tab1, tab2, tab3 = st.tabs(["🔬 Specialized Analysis", "📋 Domain Classification", "📊 Comparative Metrics", "🔬 Term Clusters"])

        with tab0:
            st.subheader("Specialized Analysis for Translation Studies")
            st.caption("31 analysis types — industry, jobs, criticism, visibility, gender, paratexts, humor, dialect, audiovisual, pedagogy, and more.")
            ins_category = st.selectbox("Category", ["All"] + list(AI_ANALYSIS_CATEGORIES.keys()), key="ins_cat")
            if ins_category == "All":
                analysis_options = list(AI_ANALYSIS_PRESETS.keys())
            else:
                analysis_options = AI_ANALYSIS_CATEGORIES.get(ins_category, list(AI_ANALYSIS_PRESETS.keys()))
            s1, s2 = st.columns([1, 2])
            with s1:
                analysis_type = st.selectbox(
                    "Analysis type",
                    analysis_options,
                    format_func=lambda x: f"{AI_ANALYSIS_PRESETS.get(x, {}).get('icon', '')} {x}",
                    key="insights_analysis_type"
                )
                max_chars = st.slider("Text sample (chars)", 4000, 20000, 12000, key="insights_max_chars")
            with s2:
                is_custom = analysis_type == "Custom"
                custom_instructions = st.text_area(
                    "Custom instructions (required for Custom)" if is_custom else "Custom instructions for this dataset",
                    placeholder="Enter your full analysis prompt here..." if is_custom else "e.g. Focus on job ads; Compare reception in UK vs US; Emphasize feminist translation strategies...",
                    key="insights_custom",
                    height=100 if is_custom else 80
                )
            if st.button("🚀 Run Analysis", type="primary", key="insights_run"):
                with st.spinner(f"Analyzing ({analysis_type})..."):
                    result = ai_specialized_analysis(text, analysis_type, gemini_key,
                                                     custom_instructions=custom_instructions, max_chars=max_chars)
                st.session_state[f"insights_result_{analysis_type.replace(' ', '_')}"] = result
            result_key = f"insights_result_{analysis_type.replace(' ', '_')}"
            if st.session_state.get(result_key):
                with st.expander(f"📄 {analysis_type} — Results", expanded=True):
                    res = st.session_state[result_key]
                    st.markdown(res)
                    if "|" in res:
                        rows = []
                        for line in res.strip().split("\n"):
                            if "|" in line and not line.strip().startswith("-"):
                                parts = [p.strip() for p in line.split("|")]
                                if len(parts) >= 2:
                                    rows.append(parts)
                        if rows:
                            df_res = pd.DataFrame(rows)
                            st.dataframe(style_table_full(df_res, header_color="#ccfbf1", zebra_color="#f0fdfa"), use_container_width=True)
                            st.download_button("📥 Download CSV", df_res.to_csv(index=False).encode("utf-8"),
                                              f"insights_{analysis_type.replace(' ', '_')}.csv", "text/csv", key="insights_dl")

        with tab1:
            st.subheader("AI Domain & Genre Classification")
            if st.button("Classify Domain"):
                with st.spinner("AI classifying..."):
                    prompt = """Classify this corpus. Return a TABLE format:
Domain | Confidence | Sub-domain | Key indicators
Use pipe | as separator. 3-5 rows."""
                    raw = get_llm_response(prompt, text[:6000], gemini_key)
                    st.markdown(raw)
                    if "|" in raw:
                        rows = []
                        for line in raw.strip().split("\n"):
                            if "|" in line and not line.strip().startswith("-"):
                                parts = [p.strip() for p in line.split("|")]
                                if len(parts) >= 3:
                                    rows.append({"Domain": parts[0], "Confidence": parts[1] if len(parts) > 1 else "", "Sub-domain": parts[2] if len(parts) > 2 else "", "Indicators": parts[3] if len(parts) > 3 else ""})
                        if rows:
                            df_tbl = pd.DataFrame(rows)
                            grad_col = "Confidence" if "Confidence" in df_tbl.columns else ("Value" if "Value" in df_tbl.columns else None)
                            st.dataframe(df_tbl.style.background_gradient(subset=[grad_col], cmap="GnBu") if grad_col else df_tbl, use_container_width=True)
                            st.download_button("📥 Domain CSV", df_tbl.to_csv(index=False).encode("utf-8"), "domain.csv", "text/csv", key="dl_domain")

        with tab2:
            st.subheader("AI Comparative Metrics")
            if st.button("Generate Metrics"):
                with st.spinner("AI analyzing..."):
                    stats = get_stats(text)
                    prompt = f"""Given these stats: {stats}. Suggest 5 translation-relevant metrics or observations in table:
Metric | Value | Interpretation"""
                    raw = get_llm_response(prompt, text[:4000], gemini_key)
                    st.markdown(raw)
                    if "|" in raw:
                        rows = []
                        for line in raw.strip().split("\n"):
                            if "|" in line and not line.strip().startswith("-"):
                                parts = [p.strip() for p in line.split("|")]
                                if len(parts) >= 2:
                                    rows.append({"Metric": parts[0], "Value": parts[1] if len(parts) > 1 else "", "Interpretation": parts[2] if len(parts) > 2 else ""})
                        if rows:
                            df_tbl = pd.DataFrame(rows)
                            grad_col = "Value" if "Value" in df_tbl.columns else None
                            st.dataframe(df_tbl.style.background_gradient(subset=[grad_col], cmap="GnBu") if grad_col else df_tbl, use_container_width=True)
                            st.download_button("📥 Metrics CSV", df_tbl.to_csv(index=False).encode("utf-8"), "metrics.csv", "text/csv", key="dl_metrics")

        with tab3:
            st.subheader("AI Term Clusters")
            if st.button("Extract Term Clusters"):
                with st.spinner("AI clustering terms..."):
                    prompt = """Extract 8-10 term clusters from this text. For each cluster:
ClusterName | Terms (comma-separated) | Domain
Format as pipe-separated table."""
                    raw = get_llm_response(prompt, text[:8000], gemini_key)
                    st.markdown(raw)
                    if "|" in raw:
                        rows = []
                        for line in raw.strip().split("\n"):
                            if "|" in line and not line.strip().startswith("-"):
                                parts = [p.strip() for p in line.split("|")]
                                if len(parts) >= 2:
                                    rows.append({"Cluster": parts[0], "Terms": parts[1] if len(parts) > 1 else "", "Domain": parts[2] if len(parts) > 2 else ""})
                        if rows:
                            df_tbl = pd.DataFrame(rows)
                            st.dataframe(df_tbl, use_container_width=True)
                            st.download_button("📥 Clusters CSV", df_tbl.to_csv(index=False).encode("utf-8"), "clusters.csv", "text/csv", key="dl_clusters")
