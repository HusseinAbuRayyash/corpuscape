import { Menu } from "lucide-react";

export function TopBar() {
  return (
    <header className="sticky top-0 z-50 w-full bg-[#F7F8FA]/80 backdrop-blur-md border-b border-[#E6E8EC]/50">
      <div className="mx-auto flex h-14 max-w-[1100px] items-center justify-between px-6">
        <span className="text-sm font-medium text-[#111418]">
          TransCorpus AI
        </span>
        <div className="flex items-center gap-3">
          <button
            type="button"
            className="rounded-lg px-3 py-1.5 text-sm font-medium text-[#5C6670] transition-colors hover:bg-[#E6E8EC]/50 hover:text-[#111418]"
          >
            Deploy
          </button>
          <button
            type="button"
            className="rounded-lg p-2 text-[#5C6670] transition-colors hover:bg-[#E6E8EC]/50 hover:text-[#111418]"
            aria-label="Menu"
          >
            <Menu className="h-5 w-5" strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </header>
  );
}
