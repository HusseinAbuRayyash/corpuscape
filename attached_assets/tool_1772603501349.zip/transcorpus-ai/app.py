import streamlit as st
from utils.sidebar import render_sidebar

st.set_page_config(page_title="TransCorpus AI", page_icon="📖", layout="wide", initial_sidebar_state="expanded")
render_sidebar(active="App")

# Comfy UI: Source Sans 3, warm colors, smooth motion
st.markdown("""
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --mono: #5B52C0;
        --bi: #0F8278;
        --ai: #7B5FC7;
        --mono-ring: rgba(91, 82, 192, 0.2);
        --bi-ring: rgba(15, 130, 120, 0.2);
        --ai-ring: rgba(123, 95, 199, 0.2);
        --ease: cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }
    .stApp, .main .block-container { font-family: 'Source Sans 3', sans-serif !important; max-width: 1120px; margin: 0 auto; }
    .main .block-container { padding: 2rem 1.5rem !important; }
    
    @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }
    }
    
    /* Background: soft radial + light grid */
    .hero-wrap {
        position: relative;
        background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(253,252,251,0.95), rgba(245,244,242,0.6));
    }
    .hero-wrap::before {
        content: ''; position: absolute; inset: 0; pointer-events: none;
        background-image: linear-gradient(rgba(0,0,0,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.025) 1px, transparent 1px);
        background-size: 24px 24px; opacity: 0.5;
    }
    
    /* Hero typography + motion */
    .hero-zone {
        padding: 3.5rem 0; text-align: center; position: relative; z-index: 1;
        animation: hero-fade 0.4s var(--ease) forwards;
    }
    @keyframes hero-fade {
        from { opacity: 0; transform: translateY(6px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .hero-zone h1 { font-family: 'Source Sans 3', sans-serif !important; font-size: 42px !important; font-weight: 600 !important; letter-spacing: -0.02em !important; color: #1C1917 !important; margin: 0 0 0.5rem 0 !important; line-height: 1.15 !important; }
    .hero-sub { font-size: 1.25rem !important; color: #57534E !important; font-weight: 500 !important; margin-bottom: 0.35rem !important; line-height: 1.5 !important; }
    .hero-meta { font-size: 14px !important; color: #57534E !important; font-weight: 400 !important; line-height: 1.6 !important; }
    .hero-spacer { height: 2rem; }
    
    /* Track cards */
    .track-card {
        background: #FDFCFB; border-radius: 1rem; padding: 1.75rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05); border: 1px solid #E7E5E4;
        transition: transform 0.2s var(--ease), box-shadow 0.2s var(--ease), outline 0.2s var(--ease);
        position: relative; overflow: hidden;
    }
    .track-card::before {
        content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
    }
    .track-card.track-mono::before { background: var(--mono); }
    .track-card.track-bi::before { background: var(--bi); }
    .track-card.track-ai::before { background: var(--ai); }
    .track-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px -4px rgba(0,0,0,0.08), 0 4px 8px -4px rgba(0,0,0,0.04);
    }
    .track-card.track-mono:hover { outline: 1px solid var(--mono-ring); outline-offset: -1px; }
    .track-card.track-bi:hover { outline: 1px solid var(--bi-ring); outline-offset: -1px; }
    .track-card.track-ai:hover { outline: 1px solid var(--ai-ring); outline-offset: -1px; }
    .card-marker {
        width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center;
        font-family: 'Source Sans 3', sans-serif; font-weight: 600; font-size: 14px; color: white; margin-bottom: 1rem;
    }
    .track-card.track-mono .card-marker { background: var(--mono); }
    .track-card.track-bi .card-marker { background: var(--bi); }
    .track-card.track-ai .card-marker { background: var(--ai); }
    .track-card h3 { color: #1C1917 !important; font-weight: 600 !important; font-size: 18px !important; margin: 0 0 0.5rem 0 !important; line-height: 1.3 !important; }
    .track-card .card-desc { color: #57534E; font-size: 16px; line-height: 1.6; margin-bottom: 0.75rem; }
    .track-card .card-example { font-size: 13px; color: #78716c; font-style: italic; margin-bottom: 1rem; line-height: 1.5; }
    
    /* Card stagger */
    .card-col { animation: card-stagger 0.4s var(--ease) forwards; opacity: 0; }
    .card-col-1 { animation-delay: 70ms; }
    .card-col-2 { animation-delay: 140ms; }
    .card-col-3 { animation-delay: 210ms; }
    @keyframes card-stagger {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Buttons */
    .stButton > button { transition: transform 0.2s var(--ease), box-shadow 0.2s var(--ease) !important; }
    .stButton > button:hover { transform: scale(1.02) !important; }
    .stButton > button:active { transform: scale(0.98) !important; }
    [data-testid="column"]:nth-of-type(1) .stButton > button { background: var(--mono) !important; border-color: var(--mono) !important; }
    [data-testid="column"]:nth-of-type(1) .stButton > button:hover { background: #4a429e !important; }
    [data-testid="column"]:nth-of-type(2) .stButton > button { background: var(--bi) !important; border-color: var(--bi) !important; }
    [data-testid="column"]:nth-of-type(2) .stButton > button:hover { background: #0d6b63 !important; }
    [data-testid="column"]:nth-of-type(3) .stButton > button { background: var(--ai) !important; border-color: var(--ai) !important; }
    [data-testid="column"]:nth-of-type(3) .stButton > button:hover { background: #654ea8 !important; }
    
    /* Quick start accordion */
    [data-testid="stExpander"] summary { border: 1px solid #E7E5E4; border-radius: 10px; padding: 0.6rem 1rem !important; background: #FDFCFB !important; transition: background 0.2s var(--ease), border-color 0.2s var(--ease); }
    [data-testid="stExpander"] summary:hover { background: #F5F4F2 !important; border-color: #E7E5E4; }
    [data-testid="stExpander"] .stMarkdown { padding: 0.5rem 0 !important; }
    
    .main header [data-testid="stPageLink"] { display: none !important; }
    section[data-testid="stSidebar"] { max-width: 220px !important; }
    section[data-testid="stSidebar"] .stExpander { border: none !important; background: transparent !important; }
</style>
""", unsafe_allow_html=True)

# Hero
st.markdown('<div class="hero-wrap">', unsafe_allow_html=True)
st.markdown("""
<div class="hero-zone">
    <h1>TransCorpus AI</h1>
    <p class="hero-sub">Build, align, and probe corpora with AI.</p>
    <p class="hero-meta">For Translation Studies research and corpus analysis.</p>
</div>
""", unsafe_allow_html=True)
st.markdown("</div>", unsafe_allow_html=True)
st.markdown("<div class='hero-spacer'></div>", unsafe_allow_html=True)

# Track cards
col1, col2, col3 = st.columns(3, gap="large")

with col1:
    st.markdown("""
    <div class="card-col card-col-1">
    <div class="track-card track-mono">
        <div class="card-marker">M</div>
        <h3>Monolingual</h3>
        <p class="card-desc">Explore reception, register, and discourse patterns in a single corpus.</p>
        <p class="card-example">Example: Keyword dispersion across 12 film subtitle corpora.</p>
    </div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("Start analysis →", key="start_mono", type="primary"):
        st.switch_page("pages/1_Monolingual.py")

with col2:
    st.markdown("""
    <div class="card-col card-col-2">
    <div class="track-card track-bi">
        <div class="card-marker">B</div>
        <h3>Bilingual</h3>
        <p class="card-desc">Align EN→AR corpora, trace shifts, export TMX.</p>
        <p class="card-example">Example: Domestication strategies in literary translations.</p>
    </div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("Start alignment →", key="start_bi", type="primary"):
        st.switch_page("pages/2_Bilingual.py")

with col3:
    st.markdown("""
    <div class="card-col card-col-3">
    <div class="track-card track-ai">
        <div class="card-marker">A</div>
        <h3>AI Insights</h3>
        <p class="card-desc">Cluster domains, probe semantics, detect hidden patterns.</p>
        <p class="card-example">Example: 31 specialized analysis types, term clusters.</p>
    </div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("Run probes →", key="start_ai", type="primary"):
        st.switch_page("pages/3_AI_Insights.py")

st.markdown("<div class='hero-spacer'></div>", unsafe_allow_html=True)

# Quick start
with st.expander("Quick start & tips", expanded=False):
    st.markdown("""
    Add your **Gemini API key** in the sidebar (Settings). Then choose a track above.  
    Monolingual: stats, keywords, collocations, concordance. Bilingual: alignment, strategies, TMX. AI Insights: domain classification, term clusters. Export: CSV, Excel, TMX, Research Report.
    """)
