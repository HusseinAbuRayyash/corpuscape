# TransCorpus AI – Research Features for Translation Studies

## For Translation Studies Researchers

This document outlines the analytical features available in TransCorpus AI, aligned with common methodologies in corpus-based translation studies.

---

## Monolingual Corpus Analysis

| Feature | Method | Use in TS Research |
|--------|--------|-------------------|
| **Corpus statistics** | TTR, word count, sentence length | Establishing corpus profile, comparability |
| **Keywords** | Frequency-based extraction | Identifying domain-specific vocabulary |
| **Collocations** | MI (Mutual Information), Dice | Phraseology, recurrent word combinations |
| **N-grams** | Bigrams, trigrams, 4-grams | Fixed expressions, formulaic language |
| **Concordance (KWIC)** | Key Word In Context | Qualitative analysis, usage patterns |
| **AI summary** | LLM-based | Quick overview, theme identification |
| **AI topics** | LLM extraction | Domain classification, thematic structure |
| **AI style/register** | LLM analysis | Register analysis, audience targeting |
| **Terminology extraction** | LLM-based | Glossary building, termbanks |
| **Semantic search** | Embedding + LLM | Finding relevant passages by meaning |

---

## Bilingual / Parallel Corpus Analysis

| Feature | Method | Use in TS Research |
|--------|--------|-------------------|
| **Sentence alignment** | Embedding similarity (sentence-transformers) | Building parallel corpora, TM |
| **Similarity scores** | Cosine similarity | Alignment quality assessment |
| **Strategy labeling** | AI (domestication, explicitation, etc.) | Translation strategy analysis |
| **Translation universals** | AI analysis | Explicitation, simplification, normalization |
| **Length ratio** | Target/Source word count | Expansion/contraction patterns |
| **TMX export** | ISO TMX 1.4 | Import into CAT tools (Trados, MemoQ, etc.) |

---

## Export Formats

- **CSV / Excel** – All tables
- **TMX** – Translation Memory eXchange (bilingual pairs)
- **Research Report** – Academic-ready Markdown with methodology, stats, citation

---

## Methodological Notes

- **Keywords:** Words > 3 characters, lowercase, frequency-ranked
- **Collocations:** Bigrams with MI and Dice (standard association measures)
- **Alignment:** all-MiniLM-L6-v2 embeddings; 1:1 mapping by highest similarity
- **AI models:** Gemini (with fallbacks); used for strategy labeling and universals

---

## Citation

> Abu-Rayyash, H. (2026). TransCorpus AI: AI-Powered Corpus Lab for Translation Studies. ATISA Pre-Workshop.
