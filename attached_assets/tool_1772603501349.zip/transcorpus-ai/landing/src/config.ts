/**
 * Configuration for track navigation.
 * Set VITE_STREAMLIT_URL when building for production.
 */
const BASE =
  import.meta.env.VITE_STREAMLIT_URL || "http://localhost:8501";

export const TRACK_ROUTES = {
  monolingual: `${BASE}/1_Monolingual`,
  bilingual: `${BASE}/2_Bilingual`,
  aiInsights: `${BASE}/3_AI_Insights`,
} as const;
