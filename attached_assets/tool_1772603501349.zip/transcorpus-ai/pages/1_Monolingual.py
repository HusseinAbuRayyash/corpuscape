import streamlit as st
import pandas as pd
import io
from utils.corpus import load_files, clean_text, get_stats, extract_keywords, extract_ngrams, concordance, extract_collocations
from utils.table_style import inject_css, TABLE_CMAPS, HEADER_COLORS, ZEBRA_COLORS, prepare_table, style_table_full
from utils.llm import (get_llm_response, get_embeddings, semantic_search, ai_summarize, ai_extract_topics,
                      ai_extract_topics_table, ai_style_register, ai_specialized_analysis,
                      AI_ANALYSIS_PRESETS, AI_ANALYSIS_CATEGORIES)
from utils.visuals import (create_radar_chart, plot_keyword_chart, plot_ngram_chart, plot_keyword_pie,
                          generate_wordcloud_image, CHART_PALETTES, PIE_PALETTES, WC_COLORMAPS)
from utils.sidebar import render_sidebar

st.set_page_config(page_title="TransCorpus AI", page_icon="📖", layout="wide")
render_sidebar(active="Monolingual")
inject_css()
st.markdown("# 📖 Monolingual Track")
st.caption("Corpus linguistics for translation studies: stats, keywords, collocations, concordance, 31 AI analysis types")

tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8 = st.tabs([
    "📤 Upload", "📊 Stats & Classic", "🔗 Collocations", "🤖 AI Analysis", "🔍 Concordance", "📐 N-grams", "📋 Terminology", "📤 Export"
])

with tab1:
    st.markdown("### Add your corpus")
    st.caption("Upload one or more files — they will be merged into a single corpus for analysis. Supports TXT, DOCX, PDF, Excel.")
    uploaded = st.file_uploader("Drag and drop files here", accept_multiple_files=True, type=["txt","docx","pdf","xlsx","xls"],
                                help="Multiple files are merged into one corpus")
    sample = st.selectbox("Or use sample", ["None", "Literary English"], help="Load a sample corpus to explore")

    if uploaded or sample != "None":
        if sample != "None":
            with open(f"samples/literary_{'en' if 'English' in sample else 'ar'}.txt", "r", encoding="utf-8") as f:
                raw = f.read()
        else:
            raw = load_files(uploaded)
        
        cleaned = clean_text(raw)
        st.session_state.monolingual_text = cleaned
        st.success(f"Corpus ready – {len(cleaned.split())} words")

with tab2:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts or select a sample in the **Upload** tab first.")
    elif "monolingual_text" in st.session_state:
        text = st.session_state.monolingual_text
        stats = get_stats(text)
        # Quick metrics
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.metric("Words", f"{stats.get('Words', 0):,}")
        with m2:
            st.metric("Unique", f"{stats.get('Unique words', 0):,}")
        with m3:
            st.metric("Sentences", f"{stats.get('Sentences', 0):,}")
        with m4:
            st.metric("TTR", f"{stats.get('Type-Token Ratio', 0):.3f}")

        st.subheader("📈 Full Statistics")
        with st.expander("✏️ Customize table", expanded=False):
            stats_show_gradient = st.checkbox("Show gradient on values", True, key="stats_grad")
            stats_cmap = st.selectbox("Color scheme", TABLE_CMAPS, index=TABLE_CMAPS.index("Blues") if "Blues" in TABLE_CMAPS else 0, key="stats_cmap")
            stats_header = st.selectbox("Header color", list(HEADER_COLORS.keys()), key="stats_header")
            stats_zebra = st.selectbox("Alternate rows", list(ZEBRA_COLORS.keys()), key="stats_zebra")
        df_stats = pd.DataFrame([stats]).T.rename(columns={0: "Value"})
        disp_stats = style_table_full(df_stats, gradient_cols=["Value"] if stats_show_gradient else None, cmap=stats_cmap,
                                     header_color=HEADER_COLORS.get(stats_header), zebra_color=ZEBRA_COLORS.get(stats_zebra))
        st.dataframe(disp_stats, use_container_width=True)

        df_kw = extract_keywords(text, top_n=30)
        st.markdown("**🔤 Classic Keywords**")
        with st.expander("✏️ Customize table", expanded=False):
            kw_rows = st.slider("Rows to show", 5, 50, 30, key="kw_rows")
            kw_show_grad = st.checkbox("Show gradient", True, key="kw_grad")
            kw_cmap = st.selectbox("Color scheme", TABLE_CMAPS, index=TABLE_CMAPS.index("GnBu") if "GnBu" in TABLE_CMAPS else 0, key="kw_cmap")
            kw_add_pct = st.checkbox("Add % column", False, key="kw_pct")
            kw_add_rank = st.checkbox("Add Rank column", False, key="kw_rank")
            kw_col_options = ["Term", "Frequency"] + (["%"] if kw_add_pct else []) + (["Rank"] if kw_add_rank else [])
            kw_cols = st.multiselect("Columns to show", kw_col_options, default=kw_col_options, key="kw_cols", help="Deselect to hide columns")
            kw_exclude_rows = st.multiselect("Exclude rows (terms)", df_kw["Term"].head(kw_rows).tolist(), key="kw_exclude_rows", help="Hide these terms from the table")
            kw_header = st.selectbox("Header color", list(HEADER_COLORS.keys()), key="kw_header")
            kw_zebra = st.selectbox("Alternate rows", list(ZEBRA_COLORS.keys()), key="kw_zebra")
        df_kw_prep = prepare_table(df_kw.head(kw_rows), columns_to_show=kw_cols if kw_cols else None,
                                  exclude_rows=kw_exclude_rows, key_column="Term",
                                  add_pct_col="Frequency" if kw_add_pct else None, add_rank_col="Frequency" if kw_add_rank else None)
        if kw_cols:
            df_kw_prep = df_kw_prep[[c for c in kw_cols if c in df_kw_prep.columns]]
        df_kw_display = style_table_full(df_kw_prep, gradient_cols=["Frequency"] if kw_show_grad and "Frequency" in df_kw_prep.columns else None,
                                        cmap=kw_cmap, header_color=HEADER_COLORS.get(kw_header, "#f1f5f9"),
                                        zebra_color=ZEBRA_COLORS.get(kw_zebra))
        st.dataframe(df_kw_display, use_container_width=True)
        ex1, ex2 = st.columns(2)
        with ex1:
            st.download_button("📥 Keywords CSV", df_kw.to_csv(index=False).encode("utf-8"), "keywords.csv", "text/csv", use_container_width=True)
        with ex2:
            try:
                xb = io.BytesIO()
                df_kw.to_excel(xb, index=False, engine="openpyxl")
                st.download_button("📥 Keywords Excel", xb.getvalue(), "keywords.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
            except Exception:
                pass

        # Charts row
        chart_opt = st.radio("Chart type", ["Bar", "Horizontal Bar", "Line", "Area", "Donut", "Word Cloud"], horizontal=True, help="Choose how to visualize keyword frequencies")

        with st.expander("✏️ Customize figure", expanded=False):
            fig_title = st.text_input("Chart title", value="📊 Top Keywords", key="kw_title")
            n_bars = st.slider("Number of items", 5, 30, 15, key="kw_nbars")
            show_labels = st.checkbox("Show value labels", True, key="kw_labels")
            show_grid = st.checkbox("Show grid lines", True, key="kw_grid")
            kw_palette = st.selectbox("Color palette", list(CHART_PALETTES.keys()), index=0, key="kw_palette")
            kw_exclude = st.multiselect("Exclude from chart", df_kw["Term"].head(n_bars).tolist(), key="kw_exclude", help="Select items to hide from the chart")
            hole_size = st.slider("Donut hole size", 0.0, 0.8, 0.5, key="kw_hole")
            wc_words = st.slider("Max words (Word Cloud)", 30, 150, 80, key="wc_max")
            wc_cmap = st.selectbox("Word Cloud colors", list(WC_COLORMAPS), index=0, key="wc_cmap")

        if chart_opt in ("Bar", "Horizontal Bar", "Line", "Area"):
            kw_type = "bar" if chart_opt == "Bar" else "hbar" if chart_opt == "Horizontal Bar" else "line" if chart_opt == "Line" else "area"
            fig = plot_keyword_chart(df_kw, chart_type=kw_type, title=fig_title, n_bars=n_bars, show_labels=show_labels,
                                    show_grid=show_grid, color_palette=kw_palette, exclude=kw_exclude)
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": True})
            try:
                png_bytes = fig.to_image(format="png")
                st.download_button("📥 Download Chart (PNG)", png_bytes, "keywords.png", "image/png")
            except Exception:
                st.caption("PNG export requires kaleido. Run: pip install kaleido==0.2.1")
        elif chart_opt == "Donut":
            fig_pie = plot_keyword_pie(df_kw, top_n=n_bars, title=fig_title, hole=hole_size, color_palette=kw_palette)
            st.plotly_chart(fig_pie, use_container_width=True, config={"displayModeBar": True})
            try:
                png_bytes = fig_pie.to_image(format="png")
                st.download_button("📥 Download Chart (PNG)", png_bytes, "keywords_donut.png", "image/png")
            except Exception:
                st.caption("PNG export requires kaleido. Run: pip install kaleido==0.2.1")
        else:
            wc_img = generate_wordcloud_image(text, max_words=wc_words, colormap=wc_cmap)
            if wc_img:
                st.image(wc_img, use_container_width=True)
                st.download_button("📥 Word Cloud (PNG)", wc_img, "wordcloud.png", "image/png")
            else:
                st.warning("Word cloud requires: pip install wordcloud")

with tab3:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        st.subheader("🔗 Collocation Analysis")
        st.caption("Phraseology: bigrams with Mutual Information (MI) and Dice. Standard in corpus-based TS.")
        node = st.text_input("Node word (optional)", key="coll_node", placeholder="e.g. translation")
        c1, c2 = st.columns(2)
        with c1:
            top_c = st.slider("Top N", 10, 50, 20)
        with c2:
            min_f = st.number_input("Min frequency", 1, 10, 2)
        if st.button("Extract collocations"):
            df_coll = extract_collocations(st.session_state.monolingual_text, node_word=node if node else None, top_n=top_c, min_freq=min_f)
            if len(df_coll) > 0:
                st.session_state.df_coll = df_coll
                if "coll_empty" in st.session_state:
                    del st.session_state.coll_empty
            else:
                st.session_state.coll_empty = True
                if "df_coll" in st.session_state:
                    del st.session_state.df_coll
        if "df_coll" in st.session_state and len(st.session_state.df_coll) > 0:
            df_coll = st.session_state.df_coll
            with st.expander("✏️ Customize table", expanded=False):
                coll_rows = st.slider("Rows to show", 5, 50, 20, key="coll_rows")
                coll_cols = st.multiselect("Columns to show", list(df_coll.columns), default=list(df_coll.columns), key="coll_cols", help="Deselect to hide columns")
                coll_exclude = st.multiselect("Exclude rows (collocates)", df_coll["Collocate"].head(coll_rows).tolist(), key="coll_exclude", help="Hide these collocates")
                coll_grad = st.checkbox("Show gradient on MI/Dice", True, key="coll_grad")
                coll_cmap = st.selectbox("Color scheme", TABLE_CMAPS, index=TABLE_CMAPS.index("GnBu") if "GnBu" in TABLE_CMAPS else 0, key="coll_cmap")
                coll_header = st.selectbox("Header color", list(HEADER_COLORS.keys()), key="coll_header")
                coll_zebra = st.selectbox("Alternate rows", list(ZEBRA_COLORS.keys()), key="coll_zebra")
            df_coll_prep = prepare_table(df_coll.head(coll_rows), columns_to_show=coll_cols if coll_cols else None,
                                        exclude_rows=coll_exclude, key_column="Collocate")
            if coll_cols:
                df_coll_prep = df_coll_prep[[c for c in coll_cols if c in df_coll_prep.columns]]
            df_disp = style_table_full(df_coll_prep, gradient_cols=["MI", "Dice"] if coll_grad and any(c in df_coll_prep.columns for c in ["MI", "Dice"]) else None,
                                      cmap=coll_cmap, header_color=HEADER_COLORS.get(coll_header), zebra_color=ZEBRA_COLORS.get(coll_zebra))
            st.dataframe(df_disp, use_container_width=True)
            st.download_button("📥 Collocations CSV", st.session_state.df_coll.to_csv(index=False).encode("utf-8"), "collocations.csv", "text/csv", key="coll_csv")
        if st.session_state.get("coll_empty"):
            st.info("No collocations found. Try lowering min frequency or a different node word.")

with tab4:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        text = st.session_state.monolingual_text
        gemini_key = st.session_state.get("gemini_key")
        if not gemini_key:
            st.warning("Add your Gemini API key in the sidebar to use AI features.")
        else:
            st.subheader("🔬 Specialized Analysis")
            st.caption("31 analysis types — language industry, jobs, criticism, visibility, gender, paratexts, humor, dialect, audiovisual, pedagogy, and more.")
            ai_category = st.selectbox("Category", ["All"] + list(AI_ANALYSIS_CATEGORIES.keys()), key="ai_cat")
            if ai_category == "All":
                analysis_options = list(AI_ANALYSIS_PRESETS.keys())
            else:
                analysis_options = AI_ANALYSIS_CATEGORIES.get(ai_category, list(AI_ANALYSIS_PRESETS.keys()))
            a1, a2 = st.columns([1, 2])
            with a1:
                analysis_type = st.selectbox(
                    "Analysis type",
                    analysis_options,
                    format_func=lambda x: f"{AI_ANALYSIS_PRESETS.get(x, {}).get('icon', '')} {x}",
                    key="ai_analysis_type"
                )
                max_chars = st.slider("Text sample (chars)", 4000, 20000, 12000, key="ai_max_chars", help="Larger = more context, slower")
                batch_modes = st.checkbox("Batch run (multiple analyses)", False, key="ai_batch")
                batch_types = []
                if batch_modes:
                    batch_types = st.multiselect("Select analyses to run", analysis_options, default=[], key="ai_batch_types",
                                                 format_func=lambda x: f"{AI_ANALYSIS_PRESETS.get(x, {}).get('icon', '')} {x}")
            with a2:
                is_custom = analysis_type == "Custom"
                custom_instructions = st.text_area(
                    "Custom instructions (required for Custom)" if is_custom else "Custom instructions (optional)",
                    placeholder="Enter your full analysis prompt here..." if is_custom else "e.g. Focus on literary translation; Compare with norms in EN; Emphasize paratextual visibility...",
                    key="ai_custom_inst",
                    height=100 if is_custom else 80
                )
            if st.button("🚀 Run Analysis", type="primary", key="ai_run"):
                if batch_modes and batch_types:
                    for i, atype in enumerate(batch_types):
                        with st.spinner(f"Analyzing ({i+1}/{len(batch_types)}): {atype}..."):
                            result = ai_specialized_analysis(text, atype, gemini_key,
                                                             custom_instructions=custom_instructions, max_chars=max_chars)
                        st.session_state[f"ai_result_{atype}"] = result
                    st.success(f"Completed {len(batch_types)} analyses.")
                else:
                    with st.spinner(f"Analyzing ({analysis_type})..."):
                        result = ai_specialized_analysis(text, analysis_type, gemini_key,
                                                         custom_instructions=custom_instructions, max_chars=max_chars)
                    st.session_state[f"ai_result_{analysis_type}"] = result
                    st.session_state.ai_last_analysis = (analysis_type, result)
            # Show results: for batch, show all completed; else show current type
            results_to_show = list(batch_types) if batch_modes and batch_types else ([analysis_type] if analysis_type else [])
            for res_type in results_to_show:
                if st.session_state.get(f"ai_result_{res_type}", ""):
                    with st.expander(f"📄 {res_type} — Results", expanded=True):
                        res = st.session_state[f"ai_result_{res_type}"]
                        st.markdown(res)
                        if "|" in res:
                            rows = []
                            for line in res.strip().split("\n"):
                                if "|" in line and not line.strip().startswith("-"):
                                    parts = [p.strip() for p in line.split("|")]
                                    if len(parts) >= 2:
                                        rows.append(parts)
                            if rows:
                                df_res = pd.DataFrame(rows)
                                st.dataframe(df_res, use_container_width=True)
                                st.download_button("📥 Download CSV", df_res.to_csv(index=False).encode("utf-8"),
                                                  f"ai_analysis_{res_type.replace(' ', '_')}.csv", "text/csv", key=f"ai_dl_{res_type}")

            st.divider()
            st.subheader("📋 Classic Analyses")
            c1, c2 = st.columns(2)
            with c1:
                if st.button("📝 Corpus Summary"):
                    summary = ai_summarize(text, gemini_key)
                    st.session_state.ai_summary_for_report = summary
                    with st.expander("📄 Corpus Summary", expanded=True):
                        st.markdown(summary)
                if st.button("🎭 Style & Register"):
                    with st.spinner("Analyzing..."):
                        style = ai_style_register(text, gemini_key)
                    with st.expander("🎭 Style & Register", expanded=True):
                        st.markdown(style)
            with c2:
                if st.button("📊 Extract Topics"):
                    with st.spinner("Extracting themes..."):
                        rows = ai_extract_topics_table(text, gemini_key)
                    if rows:
                        df_topics = pd.DataFrame(rows)
                        st.dataframe(df_topics, use_container_width=True)
                        st.download_button("📥 Topics CSV", df_topics.to_csv(index=False).encode("utf-8"), "topics.csv", "text/csv", key="topics_csv")
                    else:
                        raw = ai_extract_topics(text, gemini_key, n_topics=8)
                        st.markdown(raw)

            st.divider()
            st.subheader("🔍 Semantic Search")
            query = st.text_input("Ask anything (e.g. 'instances of cultural adaptation')", key="sem_query")
            if query and st.button("Search"):
                with st.spinner("Searching..."):
                    results = semantic_search(text=text, query=query, gemini_key=gemini_key)
                    st.write(results)

with tab5:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        st.subheader("🔍 Concordance (Key Word In Context)")
        kw = st.text_input("Search term or phrase", key="concord")
        cw = st.slider("Context words", 3, 15, 5)
        if kw and st.button("Find"):
            df_conc = concordance(st.session_state.monolingual_text, kw, context_words=cw)
            if len(df_conc) > 0:
                st.session_state.df_conc = df_conc
                if "conc_empty" in st.session_state:
                    del st.session_state.conc_empty
            else:
                st.session_state.conc_empty = kw
                if "df_conc" in st.session_state:
                    del st.session_state.df_conc
        if "df_conc" in st.session_state and len(st.session_state.df_conc) > 0:
            df_conc = st.session_state.df_conc
            with st.expander("✏️ Customize concordance table", expanded=False):
                conc_rows = st.slider("Hits to show", 5, 100, 50, key="conc_rows")
                conc_cols = st.multiselect("Columns to show", ["Left", "Match", "Right"], default=["Left", "Match", "Right"], key="conc_cols", help="Deselect to hide columns")
                conc_exclude = st.multiselect("Exclude hits", list(range(1, min(conc_rows, len(df_conc)) + 1)), key="conc_exclude", format_func=lambda x: f"Hit #{x}", help="Hide specific hits by number")
                conc_highlight = st.checkbox("Highlight match column", True, key="conc_hl")
                conc_header = st.selectbox("Header color", list(HEADER_COLORS.keys()), key="conc_header")
                conc_zebra = st.selectbox("Alternate rows", list(ZEBRA_COLORS.keys()), key="conc_zebra")
            df_conc_d = df_conc.head(conc_rows)
            if conc_exclude:
                exclude_idx = [i - 1 for i in conc_exclude]
                df_conc_d = df_conc_d[~df_conc_d.index.isin(exclude_idx)]
            if conc_cols:
                df_conc_d = df_conc_d[[c for c in conc_cols if c in df_conc_d.columns]]
            df_conc_style = style_table_full(df_conc_d, highlight_col="Match" if conc_highlight else None,
                                            header_color=HEADER_COLORS.get(conc_header), zebra_color=ZEBRA_COLORS.get(conc_zebra))
            st.dataframe(df_conc_style, use_container_width=True)
            st.download_button("📥 Concordance CSV", st.session_state.df_conc.to_csv(index=False).encode("utf-8"), "concordance.csv", "text/csv")
        if st.session_state.get("conc_empty"):
            st.info(f"No matches found for «{st.session_state.conc_empty}»")

with tab6:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        st.subheader("📐 N-gram Analysis")
        n = st.selectbox("N-gram size", [2, 3, 4], format_func=lambda x: ["Bigrams", "Trigrams", "4-grams"][x-2])
        top = st.slider("Top N", 10, 50, 25)
        df_ng = extract_ngrams(st.session_state.monolingual_text, n=n, top_n=top)
        ng_label = ["Bigrams", "Trigrams", "4-grams"][n-2]
        st.markdown(f"**📐 Top {top} {ng_label}**")
        with st.expander("✏️ Customize table", expanded=False):
            ng_rows = st.slider("Rows to show", 5, 50, top, key="ng_rows")
            ng_add_pct = st.checkbox("Add % column", False, key="ng_pct")
            ng_add_rank = st.checkbox("Add Rank column", False, key="ng_rank")
            ng_col_options = ["N-gram", "Frequency"] + (["%"] if ng_add_pct else []) + (["Rank"] if ng_add_rank else [])
            ng_cols = st.multiselect("Columns to show", ng_col_options, default=ng_col_options, key="ng_cols", help="Deselect to hide columns")
            ng_exclude_rows = st.multiselect("Exclude rows (n-grams)", df_ng["N-gram"].head(ng_rows).tolist(), key="ng_exclude_rows", help="Hide these n-grams")
            ng_grad = st.checkbox("Show gradient", True, key="ng_grad")
            ng_cmap = st.selectbox("Color scheme", TABLE_CMAPS, index=TABLE_CMAPS.index("GnBu") if "GnBu" in TABLE_CMAPS else 0, key="ng_cmap")
            ng_header = st.selectbox("Header color", list(HEADER_COLORS.keys()), key="ng_header")
            ng_zebra = st.selectbox("Alternate rows", list(ZEBRA_COLORS.keys()), key="ng_zebra")
        df_ng_prep = prepare_table(df_ng.head(ng_rows), columns_to_show=ng_cols if ng_cols else None,
                                  exclude_rows=ng_exclude_rows, key_column="N-gram",
                                  add_pct_col="Frequency" if ng_add_pct else None, add_rank_col="Frequency" if ng_add_rank else None)
        if ng_cols:
            df_ng_prep = df_ng_prep[[c for c in ng_cols if c in df_ng_prep.columns]]
        df_ng_display = style_table_full(df_ng_prep, gradient_cols=["Frequency"] if ng_grad and "Frequency" in df_ng_prep.columns else None,
                                        cmap=ng_cmap, header_color=HEADER_COLORS.get(ng_header), zebra_color=ZEBRA_COLORS.get(ng_zebra))
        st.dataframe(df_ng_display, use_container_width=True)
        n1, n2 = st.columns(2)
        with n1:
            st.download_button("📥 N-grams CSV", df_ng.to_csv(index=False).encode("utf-8"), f"ngrams_{n}.csv", "text/csv", key="ng_csv")
        with n2:
            try:
                xb = io.BytesIO()
                df_ng.to_excel(xb, index=False, engine="openpyxl")
                st.download_button("📥 N-grams Excel", xb.getvalue(), f"ngrams_{n}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key="ng_xlsx")
            except Exception:
                pass
        with st.expander("✏️ Customize N-gram chart", expanded=False):
            ng_fig_title = st.text_input("Chart title", value=f"📐 Top 15 {ng_label}", key="ng_fig_title")
            ng_chart_type = st.radio("Chart type", ["Bar", "Horizontal Bar", "Line", "Area"], horizontal=True, key="ng_chart_type")
            ng_n_bars = st.slider("Bars to show", 5, 25, 15, key="ng_n_bars")
            ng_labels = st.checkbox("Show value labels", True, key="ng_labels")
            ng_grid = st.checkbox("Show grid", True, key="ng_grid")
            ng_x_angle = st.slider("X-axis label angle", -90, 0, -45, key="ng_xangle")
            ng_palette = st.selectbox("Color palette", list(CHART_PALETTES.keys()), index=0, key="ng_palette")
            ng_exclude = st.multiselect("Exclude from chart", df_ng["N-gram"].head(ng_n_bars).tolist(), key="ng_exclude", help="Select n-grams to hide from the chart")
        ng_type = "bar" if ng_chart_type == "Bar" else "hbar" if ng_chart_type == "Horizontal Bar" else "line" if ng_chart_type == "Line" else "area"
        fig_ng = plot_ngram_chart(df_ng, chart_type=ng_type, title=ng_fig_title, n_bars=ng_n_bars, show_labels=ng_labels,
                                 show_grid=ng_grid, x_angle=ng_x_angle, color_palette=ng_palette, exclude=ng_exclude)
        st.plotly_chart(fig_ng, use_container_width=True, config={"displayModeBar": True})
        try:
            png_bytes = fig_ng.to_image(format="png")
            st.download_button("📥 Download Chart (PNG)", png_bytes, f"ngrams_{n}.png", "image/png", key="ng_png")
        except Exception:
            st.caption("PNG export requires kaleido. Run: pip install kaleido==0.2.1")

with tab7:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        if st.button("Extract Terminology"):
            with st.spinner("Using Gemini..."):
                st.session_state.terms_result = get_llm_response("Extract 20 domain-specific terms with frequency and example sentence", 
                                       st.session_state.monolingual_text[:8000], 
                                       st.session_state.get("gemini_key"))
        if "terms_result" in st.session_state and st.session_state.terms_result:
            with st.expander("📋 Extracted Terminology", expanded=True):
                st.markdown(st.session_state.terms_result)

with tab8:
    if "monolingual_text" not in st.session_state:
        st.info("👆 Upload texts first in the **Upload** tab.")
    elif "monolingual_text" in st.session_state:
        from utils.export_formats import export_research_report
        st.subheader("📤 Export")
        st.caption("Generate an academic-ready research report for papers, dissertations, or methodology sections.")
        if st.button("📄 Generate Research Report (Markdown)"):
            stats = get_stats(st.session_state.monolingual_text)
            kw = extract_keywords(st.session_state.monolingual_text, top_n=30)
            bin_df = st.session_state.get("aligned_df")
            ai_sum = st.session_state.get("ai_summary_for_report", "")
            ai_analyses = [(k.replace("ai_result_", ""), v) for k, v in st.session_state.items()
                           if k.startswith("ai_result_") and v and str(v).strip()]
            report = export_research_report(mono_stats=stats, mono_keywords=kw, bilingual_df=bin_df,
                                           ai_summary=ai_sum, ai_analyses=ai_analyses)
            st.session_state.report_md = report
        if "report_md" in st.session_state:
            st.download_button("📥 Download Report (MD)", st.session_state.report_md.encode("utf-8"), "transcorpus_report.md", "text/markdown")
            with st.expander("Preview report"):
                st.markdown(st.session_state.report_md)
        # Real ZIP code is in utils (you can expand later)
